# Changelog

## 0.3.0-dev — purification, status UI and cosmetic race models

- Added Celestial Core and Infernal Core custom items with rare shaped recipes.
- Added Divine Purification and Infernal Purification artifacts with a server-side two-use confirmation window and matching race validation.
- Purification resets the race lock and karma while deliberately retaining independent anti-farming histories and daily reward caps.
- Added custom pixel-art icons for all four new items and item model definitions.
- Added a non-pausing V-key status screen for karma, race, rank, unlocked passives/actives and cooldown state.
- Added S2C player status snapshots for race/rank/karma and cooldowns; snapshots refresh on join, progression changes, successful ability activation, respawn, dimension change, admin override and purification.
- Added client-only player render layer registration using the 1.21.11 `AvatarRenderer`/`AvatarRenderState` pipeline.
- Added cosmetic angel wings/halo and demon wings/horns with rank-based additional wing pairs; the models do not affect collision, flight, armor, or player skin textures.
- Added wing textures, fixed the left/right wing geometry mirroring, and extended the Demon Lord's highest-tier wing silhouette.
- Ensured temporary active zones terminate if their owner loses the required race power.
- Added a client-side countdown derived from server-synced cooldown snapshots.
- Re-broadcast status after respawn, dimension changes and configuration reload.
- Updated build and feature documentation. Full Gradle compilation and in-game testing remain outstanding because this environment cannot access external dependency repositories and has no Gradle installation.
- Corrected empty-slot whitespace in both purification shaped recipes so they parse as valid vanilla crafting patterns.
- Moved status-screen labels and cooldown states into the English language resource.

## 0.2.0-dev — active abilities and custom audio

- Added six rebindable Controls-menu key mappings (three Angel, three Demon).
- Added a bounded client-to-server ability request payload; race, rank, cooldown, target, range, and combat checks remain server authoritative.
- Added Holy Burst, Divine Judgement, Heaven's Wrath, Infernal Blast, Hellfire Chains, and Infernal Cataclysm logic.
- Added persistent per-player cooldown timestamps.
- Added all seven user-supplied sound cues as mono 44.1 kHz OGG Vorbis assets and registered them in `sounds.json`.
- Added cleanup for delayed judgements and owner-bound zones when their caster disconnects.
- Corrected Heaven's Wrath ally classification so only actual scoreboard allies receive healing when friendly fire is disabled.
- Reduced zone particle update frequency to keep simultaneous SMP zones lighter.

This is a source-development archive. It has not been Gradle-compiled or runtime-tested in this environment.

