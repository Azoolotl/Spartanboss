# Heaven & Hell — Fabric 1.21.11

A server-authoritative karma and race progression mod for Minecraft Java Edition, designed for competitive Survival Multiplayer.

## Exact target environment
- Minecraft Java Edition **1.21.11**
- Fabric Loader **0.20.1**
- Java **21**
- Official Mojang mappings
- Fabric API **0.141.6+1.21.11**
- Fabric Loom **1.14.10** (Gradle 9.2+)

## Current development status — 0.3.0-dev

This archive contains the source project and resources. It is not yet a compiled/distributable JAR.

### Implemented in source

**Progression and persistence**
- UUID-keyed player records stored in `world/data/heavenhell_players.json`.
- Atomic temp-file replacement and corrupt-save backup handling.
- Karma clamped to -100..+100, with configurable event values and rank thresholds.
- First transformation permanently locks Human → Angel or Human → Demon; karma cannot automatically swap the race.
- Ranks are dynamically derived from karma. Dropping below Rank I makes a player powerless without deleting race identity or progression history.
- Administrative reset and race override commands.
- Persistent PvP same-pair cooldown, help cooldowns, gift diminishing returns and daily caps.
- Automatic direct player-kill karma and hostile/passive mob-kill karma; gift/help/revival/betrayal are available through the integration API.

**Angel and Demon gameplay**
- Angel: Divine Blessing healing, Archangel/Seraphim Resistance, reduced fall damage, Seraphim poison removal and hostile-mob fear pulses.
- Demon: Fire Resistance, Emberborn ignition, Bloodthirst healing and Demon Lord Dread Presence.
- Configurable Nether Angel and Overworld Demon Weakness/Slowness penalties.
- Six server-authoritative active abilities, each with persistent cooldowns, validated race/rank, bounded packet input, and server-calculated effects.
- Abilities: Holy Burst, Divine Judgement, Heaven's Wrath, Infernal Blast, Hellfire Chains and Infernal Cataclysm.
- Server-side zone cleanup when zones expire, the owner disconnects/dies/changes dimension, or the owner loses the required race power.
- Scoreboard ally checks and vanilla `Level.mayInteract` permission checks are used where supported. Protection plugins that use different APIs may need a dedicated compatibility module.

**Audio, UI and multiplayer sync**
- Seven supplied sound effects converted to mono 44.1 kHz OGG Vorbis and registered in `sounds.json`.
- Six ability keybinds in Options → Controls: G/H/J for Angel abilities and Z/X/C for Demon abilities.
- V opens a compact, non-pausing progression screen showing server-synced karma, race, rank, unlocked passives/actives and local countdowns for cooldown snapshots.
- Server sends race/rank/karma snapshots to every online client render cache through a bounded S2C payload; snapshots are refreshed on join, progression changes, ability activation, respawn, administrative overrides and purification.

**Purification artifacts and recipes**
- `Celestial Core` and `Infernal Core` rare crafting ingredients.
- `Divine Purification` and `Infernal Purification` are stack-size-one epic artifacts.
- Using the correct artifact twice within the configured confirmation window resets the matching race to Human and karma to zero; the second use consumes the artifact (unless the player is in Creative mode).
- Purification clears racial ability cooldown/progression state but intentionally retains independent anti-farming histories and daily caps.
- Four shaped recipes are included: two cores and two purification artifacts. Recipes are data-pack resources and server packs can replace them. Purification use itself can be disabled in config.

**Cosmetic transformation layer**
- Client-only custom player render layer; it does not replace player skin, armor, held items or equipment and gives no flight or movement bonus.
- Angels display feathered wings and a halo; Archangels gain a second wing pair; Seraphim gain a third pair.
- Demons display crimson wings and horns; Archdemons gain a second pair; Demon Lords gain a third, longer pair.
- All cosmetic state is driven from server-synced race/rank data. Wings disappear for powerless Neutral players.
- Custom pixel-art wing textures are included.

**Administration and configuration**
- `/karma`, `/karma get`, `/karma set`, `/karma add`, `/karma remove`.
- `/race info`, `/race reset`, `/race set`.
- `/heavenhell status`, `/heavenhell reload`.
- Operator permission level 2 is required for mutating administrative commands.
- Config file: `config/heavenhell.json`; example: `config/heavenhell.example.json`.
- Configurable karma, thresholds, ability damage/healing/radii/durations/cooldowns, passive tuning, dimensional weaknesses, friendly fire, notification options, anti-farming limits and purification enable/confirmation window.
- Crafting recipes can be customized through server data packs.

## Important limitations
- Gift, help/revival and betrayal karma are API-driven. There is no safe universal way for this mod to infer arbitrary inventory transfers, revives or betrayals across all other mods.
- Third-party summoned-mob reward prevention is supported through `ProgressionEvents.markNoKarmaReward(entity)`, but a universal spawn-origin tracker for every modded spawner is not implemented.
- Reduced natural regeneration and passive animal-follow AI are not implemented in this build.
- Seraphim fear is implemented as a chance to drop a mob's target and apply brief Slowness; it is not a full AI panic state.
- Visual transformation includes wings, halo and horns. Glowing-eye skin overlays and elaborate rank-specific aura shaders are not implemented; the existing aura particles provide the in-world glow cue.
- Ability protection checks use vanilla `Level.mayInteract` and normal scoreboard ally checks. Dedicated hooks may be required for some region-protection plugins.
- The client render layer and multiplayer behavior have been source-reviewed against 1.21.11 / Fabric API signatures, but cannot be declared runtime-tested until a real client/server build and smoke test are run.

## Controls
| Default key | Ability | Unlock | Cooldown |
|---|---|---|---:|
| G | Holy Burst | Lesser Angel | 35 s |
| H | Divine Judgement | Archangel | 55 s |
| J | Heaven's Wrath | Seraphim | 120 s |
| Z | Infernal Blast | Lesser Demon | 35 s |
| X | Hellfire Chains | Archdemon | 55 s |
| C | Infernal Cataclysm | Demon Lord | 120 s |
| V | Open status screen | Any player | — |

## Sound assignments
- `holy_burst`: Holy Burst.
- `divine_judgement`: Divine Judgement telegraph/cast.
- `heavens_wrath`: Heaven's Wrath.
- `infernal_blast`: Infernal Blast.
- `hellfire_chains_hit` / `hellfire_chains_miss`: successful chain hit / missed target.
- `infernal_cataclysm`: Infernal Cataclysm.

## Karma integration API
On the logical server, call `KarmaService.award(ServerPlayer actor, ServerPlayer target, KarmaEvent event)` only after the event has completed successfully. The target is required for player kill, help and gift events; mob kill events use a null target. A custom-value overload is also available. Do not trust client messages to award karma without server-side validation.

`ProgressionEvents.markNoKarmaReward(entity)` explicitly blacklists summoned/scripted mobs from karma rewards.

## Build instructions
Use Java 21 and Gradle 9.2 or newer with access to Fabric Maven, Gradle Plugin Portal and Maven Central:

```sh
gradle build
```

The distributable mod JAR, if compilation succeeds, will be in `build/libs/`. Install the same mod JAR on the server and every connecting client because abilities use client keybinds, status UI and cosmetic rendering.

**Build verification status:** this development environment has Java 21 but no Gradle installation or Gradle wrapper, and cannot resolve the external dependency repositories. Therefore no successful Gradle compile or Minecraft runtime test has been performed here. Do not treat this source ZIP as a finished JAR.
