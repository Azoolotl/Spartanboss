# Visual Direction — Heaven & Hell

The supplied reference images are included here for the future client-rendering and asset-authoring stages. They are design references only; they are not loaded as in-game textures or models by the current build.

## Angels
- White, ivory, and gold palette.
- Soft golden aura, luminous eyes, small floating holy particles.
- Lesser Angel: one modest pair of feathered wings and a subtle halo.
- Archangel: larger, more elaborate wings, stronger gold trim and a brighter halo.
- Seraphim: six radiant wings, an elaborate halo, and the strongest golden particle effects.

## Demons
- Black, charcoal, and crimson palette.
- Glowing red eyes, dark-red aura, smoke and ember particles.
- Lesser Demon: modest horns and one pair of dark bat-like wings.
- Archdemon: larger horns and wings, stronger ember effects.
- Demon Lord: large intimidating wings, an elaborate horn silhouette, and the strongest dark-red aura and smoke.

## Technical constraints
- Cosmetic only: wings and halos must not grant flight, armor, hitboxes, or movement changes.
- Render as player model attachments so the player's skin and equipped armor remain intact.
- All visible effects must be driven by server-synchronized race/rank state.
- Keep particle density configurable and avoid spawning particle entities.
