package com.kuku.heavenhell.api;

/** Extensible event identifiers for integrations and server-side gameplay hooks. */
public enum KarmaEvent {
    HELP_PLAYER, RESOURCE_GIFT, HOSTILE_MOB_KILL, PASSIVE_MOB_KILL, PLAYER_KILL, BETRAYAL
}
