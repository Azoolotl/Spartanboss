package com.kuku.heavenhell.api;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.data.PlayerData;
import com.kuku.heavenhell.data.Race;
import com.kuku.heavenhell.data.Rank;
import com.kuku.heavenhell.network.StatusSync;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.Iterator;
import java.util.Map;

/** Server-authoritative karma API for this mod and other server-side integrations. */
public final class KarmaService {
    private static final long CLEANUP_AGE_MILLIS = 30L * 24L * 60L * 60L * 1000L;
    private KarmaService() {}

    public static boolean award(ServerPlayer actor, ServerPlayer target, KarmaEvent event) {
        if (actor == null || event == null) return false;
        int amount = switch (event) {
            case HELP_PLAYER -> HeavenHell.CONFIG.karmaHelp;
            case RESOURCE_GIFT -> HeavenHell.CONFIG.karmaGift;
            case HOSTILE_MOB_KILL -> HeavenHell.CONFIG.karmaHostileKill;
            case PASSIVE_MOB_KILL -> HeavenHell.CONFIG.karmaPassiveKill;
            case PLAYER_KILL -> HeavenHell.CONFIG.karmaPlayerKill;
            case BETRAYAL -> HeavenHell.CONFIG.karmaBetrayal;
        };
        if (event == KarmaEvent.PLAYER_KILL && target != null) {
            PlayerData killer = HeavenHell.DATA.get(actor.getUUID());
            PlayerData victim = HeavenHell.DATA.get(target.getUUID());
            if (victim.karma > killer.karma + 20) amount += HeavenHell.CONFIG.karmaHigherKarmaKillBonus;
        }
        return award(actor, target, event, amount);
    }

    /**
     * Explicit-value variant for integrations. RESOURCE_GIFT, HELP_PLAYER, PvP and mob rewards
     * still pass through the same farming protections as built-in events.
     */
    public static boolean award(ServerPlayer actor, ServerPlayer target, KarmaEvent event, int requestedAmount) {
        if (actor == null || actor.level().getServer() == null || event == null) return false;
        if (target != null && actor.getUUID().equals(target.getUUID())) return false;

        long now = System.currentTimeMillis();
        long day = LocalDate.now(ZoneOffset.UTC).toEpochDay();
        PlayerData data = HeavenHell.DATA.get(actor.getUUID());
        int amount = Math.max(-100, Math.min(100, requestedAmount));

        switch (event) {
            case PLAYER_KILL -> {
                if (target == null) return false;
                String victimId = target.getUUID().toString();
                long previous = data.playerKillCooldowns.getOrDefault(victimId, 0L);
                long cooldown = HeavenHell.CONFIG.samePlayerKillCooldownSeconds * 1000L;
                if (now - previous < cooldown) return false;
                data.playerKillCooldowns.put(victimId, now);
                cleanupOldEntries(data.playerKillCooldowns, now);
            }
            case HELP_PLAYER -> {
                if (target == null) return false;
                String recipientId = target.getUUID().toString();
                long previous = data.helpRewardCooldowns.getOrDefault(recipientId, 0L);
                long cooldown = HeavenHell.CONFIG.helpRewardCooldownSeconds * 1000L;
                if (now - previous < cooldown) return false;
                data.helpRewardCooldowns.put(recipientId, now);
                cleanupOldEntries(data.helpRewardCooldowns, now);
            }
            case RESOURCE_GIFT -> {
                if (target == null || HeavenHell.CONFIG.transferDailyCap <= 0) return false;
                if (data.giftRewardDay != day) {
                    data.giftRewardDay = day;
                    data.giftKarmaEarnedToday = 0;
                }
                if (data.giftKarmaEarnedToday >= HeavenHell.CONFIG.transferDailyCap) return false;
                PlayerData.GiftState state = data.giftState(target.getUUID(), day);
                if (state.rewardedTransfers >= HeavenHell.CONFIG.rewardedGiftTransfersPerRecipientPerDay) return false;
                // First gift receives the full value; the second gets half (rounded down, minimum 1).
                amount = state.rewardedTransfers == 0 ? Math.max(0, amount) : Math.max(1, amount / 2);
                amount = Math.min(amount, HeavenHell.CONFIG.transferDailyCap - data.giftKarmaEarnedToday);
                state.rewardedTransfers++;
                if (amount <= 0) {
                    HeavenHell.DATA.save();
                    return false;
                }
                data.giftKarmaEarnedToday += amount;
            }
            case HOSTILE_MOB_KILL -> {
                if (HeavenHell.CONFIG.mobKillDailyKarmaCap <= 0) return false;
                if (data.mobRewardDay != day) {
                    data.mobRewardDay = day;
                    data.mobKarmaEarnedToday = 0;
                }
                if (data.mobKarmaEarnedToday >= HeavenHell.CONFIG.mobKillDailyKarmaCap) return false;
                amount = Math.min(Math.max(0, amount), HeavenHell.CONFIG.mobKillDailyKarmaCap - data.mobKarmaEarnedToday);
                if (amount <= 0) return false;
                data.mobKarmaEarnedToday += amount;
            }
            case PASSIVE_MOB_KILL, BETRAYAL -> { }
        }

        int oldKarma = data.karma;
        Race oldRace = data.race;
        Rank oldRank = data.rank();
        data.addKarma(amount);
        HeavenHell.DATA.save();

        if (oldKarma != data.karma) {
            notifyProgression(actor, oldRace, oldRank, data);
            if (HeavenHell.CONFIG.actionBarNotifications) {
                int delta = data.karma - oldKarma;
                actor.displayClientMessage(Component.literal((delta >= 0 ? "§a+" : "§c") + delta + " Karma §7(" + data.karma + "/100)"), true);
            }
        }
        return oldKarma != data.karma;
    }

    public static void notifyProgression(ServerPlayer player, Race oldRace, Rank oldRank, PlayerData data) {
        StatusSync.broadcast(player);
        if (oldRace == Race.HUMAN && data.race != Race.HUMAN) {
            player.displayClientMessage(Component.literal(data.race == Race.ANGEL
                    ? "§e✦ You have ascended. You are now an Angel."
                    : "§c☠ You have fallen. You are now a Demon."), false);
            return;
        }
        Rank newRank = data.rank();
        if (oldRank == newRank) return;
        if (newRank == Rank.NONE && data.race != Race.HUMAN) {
            player.displayClientMessage(Component.literal("§7Your powers have faded. You are now powerless, but your race remains."), false);
        } else if (oldRank == Rank.NONE) {
            player.displayClientMessage(Component.literal("§6Your racial powers have returned: " + newRank.display() + "!"), false);
        } else {
            player.displayClientMessage(Component.literal(((data.race == Race.ANGEL ? newRank.threshold() > oldRank.threshold() : newRank.threshold() < oldRank.threshold()) ? "§6Rank unlocked: " : "§7Rank changed: ")
                    + newRank.display() + "!"), false);
        }
    }

    private static void cleanupOldEntries(Map<String, Long> map, long now) {
        Iterator<Map.Entry<String, Long>> iterator = map.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, Long> entry = iterator.next();
            if (now - entry.getValue() > CLEANUP_AGE_MILLIS) iterator.remove();
        }
    }
}
