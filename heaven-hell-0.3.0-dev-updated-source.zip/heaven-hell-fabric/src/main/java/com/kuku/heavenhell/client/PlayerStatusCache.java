package com.kuku.heavenhell.client;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/** Client-only cache of server-authoritative race visuals, indexed by current entity ID. */
public final class PlayerStatusCache {
    private static final Map<Integer, Status> STATUSES = new ConcurrentHashMap<>();
    private PlayerStatusCache() {}

    public static void update(int entityId, int raceId, int rankId, int karma, String cooldowns) {
        if (raceId < 0) STATUSES.remove(entityId);
        else STATUSES.put(entityId, new Status(raceId, rankId, karma, cooldowns, System.currentTimeMillis()));
    }

    public static Status get(int entityId) { return STATUSES.get(entityId); }
    public static void clear() { STATUSES.clear(); }

    public record Status(int raceId, int rankId, int karma, String cooldowns, long receivedAtMillis) {
        public int cooldownSeconds(int slot) {
            if (slot < 0 || slot > 5 || cooldowns == null) return 0;
            String[] values = cooldowns.split(",", -1);
            if (values.length != 6) return 0;
            try {
                long elapsed = Math.max(0L, (System.currentTimeMillis() - receivedAtMillis) / 1000L);
                return Math.max(0, (int) (Integer.parseInt(values[slot]) - elapsed));
            }
            catch (NumberFormatException ignored) { return 0; }
        }
        public boolean isPowered() { return rankId > 0; }
        public boolean isAngel() { return raceId == 1; }
        public boolean isDemon() { return raceId == 2; }
    }
}
