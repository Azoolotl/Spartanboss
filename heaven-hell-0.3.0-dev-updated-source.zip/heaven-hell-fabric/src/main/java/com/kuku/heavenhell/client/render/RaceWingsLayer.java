package com.kuku.heavenhell.client.render;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.client.PlayerStatusCache;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.player.PlayerModel;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.Identifier;

/** Client-only cosmetics, anchored to vanilla torso/head parts and driven by server status. */
public final class RaceWingsLayer extends RenderLayer<AvatarRenderState, PlayerModel> {
    private static final Identifier ANGEL_TEXTURE = Identifier.fromNamespaceAndPath(
            HeavenHell.MOD_ID, "textures/entity/angel_wings.png");
    private static final Identifier DEMON_TEXTURE = Identifier.fromNamespaceAndPath(
            HeavenHell.MOD_ID, "textures/entity/demon_wings.png");

    private final RaceWingsModel model;

    public RaceWingsLayer(RenderLayerParent<AvatarRenderState, PlayerModel> parent, ModelPart bakedRoot) {
        super(parent);
        this.model = new RaceWingsModel(bakedRoot);
    }

    @Override
    public void submit(PoseStack matrices, SubmitNodeCollector queue, int packedLight,
                       AvatarRenderState state, float limbAngle, float limbDistance) {
        PlayerStatusCache.Status status = PlayerStatusCache.get(state.id);
        if (status == null || !status.isPowered() || state.isInvisible || state.isSpectator) return;
        Identifier texture = status.isAngel() ? ANGEL_TEXTURE : DEMON_TEXTURE;
        int tint = 0xFFFFFFFF;

        matrices.pushPose();
        getParentModel().body.translateAndRotate(matrices);
        matrices.translate(0.0, 0.0, 0.19);
        matrices.scale(1.42F, 1.42F, 1.0F);
        model.configureWings(status.raceId(), status.rankId());
        model.setupAnim(state);
        renderColoredCutoutModel(model, texture, matrices, queue, packedLight, state, tint, OverlayTexture.NO_OVERLAY);
        matrices.popPose();

        matrices.pushPose();
        getParentModel().head.translateAndRotate(matrices);
        model.configureHead(status.raceId(), status.rankId());
        model.setupAnim(state);
        renderColoredCutoutModel(model, texture, matrices, queue, packedLight, state, tint, OverlayTexture.NO_OVERLAY);
        matrices.popPose();
    }
}
