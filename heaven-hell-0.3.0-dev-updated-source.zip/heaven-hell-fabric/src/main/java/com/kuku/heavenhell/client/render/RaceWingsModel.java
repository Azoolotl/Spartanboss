package com.kuku.heavenhell.client.render;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.client.renderer.entity.state.AvatarRenderState;

/** Large, animated cosmetic wings plus head-anchored halo and horns. */
public final class RaceWingsModel extends EntityModel<AvatarRenderState> {
    private final ModelPart leftWing;
    private final ModelPart rightWing;
    private final ModelPart leftWingTwo;
    private final ModelPart rightWingTwo;
    private final ModelPart leftWingThree;
    private final ModelPart rightWingThree;
    private final ModelPart halo;
    private final ModelPart leftHorn;
    private final ModelPart rightHorn;

    public RaceWingsModel(ModelPart root) {
        super(root);
        leftWing = root.getChild("left_wing");
        rightWing = root.getChild("right_wing");
        leftWingTwo = root.getChild("left_wing_two");
        rightWingTwo = root.getChild("right_wing_two");
        leftWingThree = root.getChild("left_wing_three");
        rightWingThree = root.getChild("right_wing_three");
        halo = root.getChild("halo");
        leftHorn = root.getChild("left_horn");
        rightHorn = root.getChild("right_horn");
    }

    public static LayerDefinition createLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();
        CubeDeformation thin = new CubeDeformation(0.035F);

        addWing(root, "left_wing", 1, -8.8F, 2.75F, 1.22F, 0.0F, thin);
        addWing(root, "right_wing", -1, -8.8F, 2.75F, 1.22F, 0.0F, thin);
        addWing(root, "left_wing_two", 1, -8.0F, 2.92F, 1.08F, 0.20F, thin);
        addWing(root, "right_wing_two", -1, -8.0F, 2.92F, 1.08F, -0.20F, thin);
        addWing(root, "left_wing_three", 1, -9.4F, 3.08F, 1.28F, -0.18F, thin);
        addWing(root, "right_wing_three", -1, -9.4F, 3.08F, 1.28F, 0.18F, thin);

        root.addOrReplaceChild("halo", CubeListBuilder.create()
                .texOffs(0, 48).addBox(-4.0F, 0.0F, -1.0F, 8.0F, 0.65F, 1.0F, thin)
                .texOffs(0, 48).addBox(-4.0F, 0.0F, 2.0F, 8.0F, 0.65F, 1.0F, thin)
                .texOffs(0, 52).addBox(-4.0F, 0.0F, -1.0F, 1.0F, 0.65F, 3.0F, thin)
                .texOffs(0, 52).addBox(3.0F, 0.0F, -1.0F, 1.0F, 0.65F, 3.0F, thin),
                PartPose.offset(0.0F, -9.35F, 0.0F));
        root.addOrReplaceChild("left_horn", CubeListBuilder.create().texOffs(32, 48)
                .addBox(-0.8F, -4.2F, -0.4F, 1.6F, 5.2F, 1.6F, thin),
                PartPose.offsetAndRotation(3.2F, -6.4F, 0.1F, 0.0F, 0.0F, 0.32F));
        root.addOrReplaceChild("right_horn", CubeListBuilder.create().texOffs(32, 48)
                .addBox(-0.8F, -4.2F, -0.4F, 1.6F, 5.2F, 1.6F, thin),
                PartPose.offsetAndRotation(-3.2F, -6.4F, 0.1F, 0.0F, 0.0F, -0.32F));
        return LayerDefinition.create(mesh, 64, 64);
    }

    private static void addWing(PartDefinition root, String name, int side, float y, float z,
                                float scale, float baseRotation, CubeDeformation deformation) {
        CubeListBuilder cubes = CubeListBuilder.create()
                .texOffs(0, 0).addBox(x(side, 0.0F, 2.0F, scale), -2.0F * scale, 0.0F, 2.0F * scale, 5.0F * scale, 1.0F, deformation)
                .texOffs(10, 0).addBox(x(side, 1.0F, 2.0F, scale), -1.0F * scale, 0.0F, 2.0F * scale, 10.0F * scale, 1.0F, deformation)
                .texOffs(22, 0).addBox(x(side, 2.5F, 2.0F, scale), 1.0F * scale, 0.0F, 2.0F * scale, 14.0F * scale, 1.0F, deformation)
                .texOffs(34, 0).addBox(x(side, 4.0F, 2.0F, scale), 3.0F * scale, 0.0F, 2.0F * scale, 13.0F * scale, 1.0F, deformation)
                .texOffs(46, 0).addBox(x(side, 5.2F, 1.0F, scale), 5.0F * scale, 0.0F, 1.0F * scale, 9.0F * scale, 1.0F, deformation);
        root.addOrReplaceChild(name, cubes,
                PartPose.offsetAndRotation(side * 2.0F, y, z, 0.0F, side * 0.05F, side * baseRotation));
    }

    private static float x(int side, float start, float width, float scale) {
        float scaledStart = start * scale;
        float scaledWidth = width * scale;
        return side > 0 ? scaledStart : -scaledStart - scaledWidth;
    }

    public void configureWings(int raceId, int rankId) {
        boolean angel = raceId == 1;
        leftWing.visible = rightWing.visible = rankId > 0;
        leftWingTwo.visible = rightWingTwo.visible = angel ? rankId >= 2 : rankId >= 5;
        leftWingThree.visible = rightWingThree.visible = angel ? rankId >= 3 : rankId >= 6;
        halo.visible = false;
        leftHorn.visible = rightHorn.visible = false;
    }

    public void configureHead(int raceId, int rankId) {
        boolean angel = raceId == 1;
        leftWing.visible = rightWing.visible = false;
        leftWingTwo.visible = rightWingTwo.visible = false;
        leftWingThree.visible = rightWingThree.visible = false;
        halo.visible = angel && rankId > 0;
        leftHorn.visible = rightHorn.visible = !angel && rankId > 0;
    }

    @Override
    public void setupAnim(AvatarRenderState state) {
        root().resetPose();
        float phase = state.ageInTicks * 0.16F;
        float flap = (float) Math.sin(phase) * 0.22F;
        float secondary = (float) Math.sin(phase - 0.35F) * 0.18F;
        float tertiary = (float) Math.sin(phase + 0.25F) * 0.16F;
        leftWing.zRot = 0.20F + flap;
        rightWing.zRot = -0.20F - flap;
        leftWingTwo.zRot = 0.34F + secondary;
        rightWingTwo.zRot = -0.34F - secondary;
        leftWingThree.zRot = 0.46F + tertiary;
        rightWingThree.zRot = -0.46F - tertiary;
        leftWing.xRot = rightWing.xRot = (float) Math.sin(phase) * 0.08F;
        leftWingTwo.xRot = rightWingTwo.xRot = (float) Math.sin(phase - 0.35F) * 0.07F;
        leftWingThree.xRot = rightWingThree.xRot = (float) Math.sin(phase + 0.25F) * 0.07F;
        halo.yRot = state.ageInTicks * 0.025F;
    }
}
