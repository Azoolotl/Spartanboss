package com.kuku.heavenhell.data;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** UUID-keyed player data in world/data/heavenhell_players.json. */
public final class PlayerDataStore {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type MAP_TYPE = new TypeToken<Map<String, StoredPlayer>>() {}.getType();
    private final Map<UUID, PlayerData> players = new HashMap<>();
    private Path file;

    public synchronized void load(MinecraftServer server) {
        file = server.getWorldPath(net.minecraft.world.level.storage.LevelResource.ROOT)
                .resolve("data/heavenhell_players.json");
        players.clear();
        if (!Files.exists(file)) return;
        try {
            Map<String, StoredPlayer> stored = GSON.fromJson(Files.readString(file), MAP_TYPE);
            if (stored == null) return;
            stored.forEach((id, value) -> {
                try {
                    UUID uuid = UUID.fromString(id);
                    PlayerData data = new PlayerData(uuid);
                    data.karma = Math.max(-100, Math.min(100, value.karma));
                    data.race = value.race == null ? Race.HUMAN : Race.valueOf(value.race);
                    data.lastUpdated = value.lastUpdated;
                    if (value.playerKillCooldowns != null) data.playerKillCooldowns.putAll(value.playerKillCooldowns);
                    if (value.helpRewardCooldowns != null) data.helpRewardCooldowns.putAll(value.helpRewardCooldowns);
                    if (value.giftStates != null) data.giftStates.putAll(value.giftStates);
                    data.giftRewardDay = value.giftRewardDay;
                    data.giftKarmaEarnedToday = Math.max(0, value.giftKarmaEarnedToday);
                    data.mobRewardDay = value.mobRewardDay;
                    data.mobKarmaEarnedToday = Math.max(0, value.mobKarmaEarnedToday);
                    data.lastDivineBlessingGameTime = value.lastDivineBlessingGameTime;
                    if (value.abilityCooldowns != null) data.abilityCooldowns.putAll(value.abilityCooldowns);
                    data.bloodthirstHitCount = Math.max(0, value.bloodthirstHitCount);
                    data.lastBloodthirstProcGameTime = value.lastBloodthirstProcGameTime;
                    data.lockRaceIfNeeded();
                    players.put(uuid, data);
                } catch (RuntimeException ignored) {
                    // Ignore malformed records; one bad player record must not prevent the world loading.
                }
            });
        } catch (RuntimeException e) {
            // Preserve a broken save for manual recovery instead of crashing world startup.
            try {
                Path backup = file.resolveSibling(file.getFileName() + ".corrupt-" + System.currentTimeMillis());
                Files.move(file, backup, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                com.kuku.heavenhell.HeavenHell.LOGGER.error(
                        "Heaven & Hell player data was malformed; moved it to {} and starting with empty records", backup, e);
            } catch (IOException backupError) {
                com.kuku.heavenhell.HeavenHell.LOGGER.error(
                        "Heaven & Hell player data was malformed and could not be backed up; starting with empty records", e);
            }
            players.clear();
        } catch (IOException e) {
            com.kuku.heavenhell.HeavenHell.LOGGER.error(
                    "Could not read Heaven & Hell player data; world will start with empty in-memory data", e);
            players.clear();
        }
    }

    public synchronized PlayerData get(UUID uuid) {
        return players.computeIfAbsent(uuid, PlayerData::new);
    }

    public synchronized Collection<PlayerData> all() {
        return Collections.unmodifiableList(new ArrayList<>(players.values()));
    }

    public synchronized void save() {
        if (file == null) return;
        Map<String, StoredPlayer> output = new TreeMap<>();
        players.forEach((uuid, data) -> output.put(uuid.toString(), new StoredPlayer(data)));
        try {
            Files.createDirectories(file.getParent());
            Path temp = file.resolveSibling(file.getFileName() + ".tmp");
            Files.writeString(temp, GSON.toJson(output));
            try {
                Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (java.nio.file.AtomicMoveNotSupportedException ignored) {
                Files.move(temp, file, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (IOException e) {
            // A filesystem problem should be visible in the log, but must not crash a server tick.
            com.kuku.heavenhell.HeavenHell.LOGGER.error("Could not save Heaven & Hell player data", e);
        }
    }

    private static final class StoredPlayer {
        int karma;
        String race;
        long lastUpdated;
        Map<String, Long> playerKillCooldowns;
        Map<String, Long> helpRewardCooldowns;
        Map<String, PlayerData.GiftState> giftStates;
        long giftRewardDay;
        int giftKarmaEarnedToday;
        long mobRewardDay;
        int mobKarmaEarnedToday;
        long lastDivineBlessingGameTime;
        Map<String, Long> abilityCooldowns;
        int bloodthirstHitCount;
        long lastBloodthirstProcGameTime;

        StoredPlayer(PlayerData data) {
            karma = data.karma;
            race = data.race.name();
            lastUpdated = data.lastUpdated;
            playerKillCooldowns = new HashMap<>(data.playerKillCooldowns);
            helpRewardCooldowns = new HashMap<>(data.helpRewardCooldowns);
            giftStates = new HashMap<>(data.giftStates);
            giftRewardDay = data.giftRewardDay;
            giftKarmaEarnedToday = data.giftKarmaEarnedToday;
            mobRewardDay = data.mobRewardDay;
            mobKarmaEarnedToday = data.mobKarmaEarnedToday;
            lastDivineBlessingGameTime = data.lastDivineBlessingGameTime;
            abilityCooldowns = new HashMap<>(data.abilityCooldowns);
            bloodthirstHitCount = data.bloodthirstHitCount;
            lastBloodthirstProcGameTime = data.lastBloodthirstProcGameTime;
        }
    }
}
