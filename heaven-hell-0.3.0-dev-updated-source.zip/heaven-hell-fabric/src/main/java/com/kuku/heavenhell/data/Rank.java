package com.kuku.heavenhell.data;

public enum Rank {
    NONE("Powerless", 0),
    LESSER_ANGEL("Lesser Angel", 20), ARCHANGEL("Archangel", 50), SERAPHIM("Seraphim", 80),
    LESSER_DEMON("Lesser Demon", -20), ARCHDEMON("Archdemon", -50), DEMON_LORD("Demon Lord", -80);

    private final String display;
    private final int threshold;
    Rank(String display, int threshold) { this.display = display; this.threshold = threshold; }
    public String display() { return display; }
    public int threshold() { return threshold; }

    public static Rank forState(Race race, int karma) {
        return forState(race, karma, 20, 50, 80, -20, -50, -80);
    }

    public static Rank forState(Race race, int karma, int angel, int archangel, int seraphim,
                                int demon, int archdemon, int demonLord) {
        if (race == Race.HUMAN) return NONE;
        if (race == Race.ANGEL) {
            if (karma < angel) return NONE;
            if (karma >= seraphim) return SERAPHIM;
            if (karma >= archangel) return ARCHANGEL;
            return LESSER_ANGEL;
        }
        if (karma > demon) return NONE;
        if (karma <= demonLord) return DEMON_LORD;
        if (karma <= archdemon) return ARCHDEMON;
        return LESSER_DEMON;
    }
}
