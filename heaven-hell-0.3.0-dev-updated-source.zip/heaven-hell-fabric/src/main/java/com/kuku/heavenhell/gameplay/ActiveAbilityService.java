package com.kuku.heavenhell.gameplay;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.audio.AbilitySounds;
import com.kuku.heavenhell.data.PlayerData;
import com.kuku.heavenhell.data.Race;
import com.kuku.heavenhell.data.Rank;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.particles.ColorParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Map;

/**
 * Server-authoritative active abilities. Client packets contain only a bounded slot index;
 * race, rank, target, dimension, cooldown, damage, and ally checks are resolved here.
 */
public final class ActiveAbilityService {
    private static final long PACKET_THROTTLE_MS = 250L;
    private static final Map<UUID, Long> LAST_REQUEST = new ConcurrentHashMap<>();
    private static final List<PendingJudgement> JUDGEMENTS = new ArrayList<>();
    private static final List<Zone> ZONES = new ArrayList<>();
    private static final List<PendingMeteor> METEORS = new ArrayList<>();

    private ActiveAbilityService() {}

    public static void onRaceReset(UUID playerId) {
        LAST_REQUEST.remove(playerId);
        JUDGEMENTS.removeIf(judgement -> judgement.owner.getUUID().equals(playerId));
        ZONES.removeIf(zone -> zone.owner.equals(playerId));
        METEORS.removeIf(meteor -> meteor.owner.equals(playerId));
    }

    public static void onDisconnect(UUID playerId) {
        LAST_REQUEST.remove(playerId);
        // Delayed attacks and owner-bound zones must not outlive a disconnected caster.
        JUDGEMENTS.removeIf(judgement -> judgement.owner.getUUID().equals(playerId));
        ZONES.removeIf(zone -> zone.owner.equals(playerId));
        METEORS.removeIf(meteor -> meteor.owner.equals(playerId));
    }

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(ActiveAbilityService::tick);
    }

    public static void activate(ServerPlayer player, int slot) {
        if (player == null || !player.isAlive() || slot < 0 || slot > 5) return;
        long now = System.currentTimeMillis();
        long previousRequest = LAST_REQUEST.getOrDefault(player.getUUID(), 0L);
        if (now - previousRequest < PACKET_THROTTLE_MS) return;
        LAST_REQUEST.put(player.getUUID(), now);

        PlayerData data = HeavenHell.DATA.get(player.getUUID());
        if (data.race == Race.HUMAN || data.isPowerless()) {
            fail(player, "You do not currently possess racial powers.");
            return;
        }
        if (!isUnlocked(data, slot)) {
            fail(player, "That ability is locked at your current rank.");
            return;
        }

        String id = abilityId(slot);
        int cooldownSeconds = cooldown(slot);
        long lastUsed = data.abilityCooldowns.getOrDefault(id, 0L);
        long remainingMillis = cooldownSeconds * 1000L - (now - lastUsed);
        if (remainingMillis > 0) {
            fail(player, "Ability recharging: " + Math.max(1, (remainingMillis + 999) / 1000) + "s");
            return;
        }

        boolean success = switch (slot) {
            case 0 -> holyBurst(player);
            case 1 -> divineJudgement(player);
            case 2 -> heavensWrath(player);
            case 3 -> infernalBlast(player);
            case 4 -> hellfireChains(player);
            case 5 -> infernalCataclysm(player);
            default -> false;
        };
        // Failed target acquisition (Divine Judgement / Chains) does not consume a cooldown.
        if (!success) return;
        data.abilityCooldowns.put(id, now);
        data.lastUpdated = now;
        HeavenHell.DATA.save();
        player.displayClientMessage(Component.literal("§6✦ " + abilityName(slot) + " activated §7— cooldown " + cooldownSeconds + "s"), true);
        com.kuku.heavenhell.network.StatusSync.broadcast(player);
    }

    private static boolean isUnlocked(PlayerData data, int slot) {
        Rank rank = data.rank();
        return switch (slot) {
            case 0 -> data.race == Race.ANGEL && rank.ordinal() >= Rank.LESSER_ANGEL.ordinal();
            case 1 -> data.race == Race.ANGEL && (rank == Rank.ARCHANGEL || rank == Rank.SERAPHIM);
            case 2 -> data.race == Race.ANGEL && rank == Rank.SERAPHIM;
            case 3 -> data.race == Race.DEMON && rank.ordinal() >= Rank.LESSER_DEMON.ordinal();
            case 4 -> data.race == Race.DEMON && (rank == Rank.ARCHDEMON || rank == Rank.DEMON_LORD);
            case 5 -> data.race == Race.DEMON && rank == Rank.DEMON_LORD;
            default -> false;
        };
    }

    private static boolean holyBurst(ServerPlayer player) {
        ServerLevel level = player.level();
        double radius = HeavenHell.CONFIG.holyBurstRadius;
        level.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 0.8, player.getZ(),
                50, radius / 2.0, 0.35, radius / 2.0, 0.12);
        level.sendParticles(ColorParticleOption.create(ParticleTypes.FLASH, 0xFFFFFF), player.getX(), player.getY() + 1.0, player.getZ(), 1, 0, 0, 0, 0);
        level.playSound(null, player.blockPosition(), AbilitySounds.HOLY_BURST, SoundSource.PLAYERS, 1.0f, 1.0f);
        player.heal(HeavenHell.CONFIG.holyBurstHeal);
        level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY() + 1.0, player.getZ(), 4, 0.35, 0.4, 0.35, 0.02);
        for (LivingEntity target : nearbyLiving(player, radius)) {
            if (isEnemy(player, target)) {
                target.hurt(player.damageSources().playerAttack(player), HeavenHell.CONFIG.holyBurstDamage);
                pushAway(player, target, HeavenHell.CONFIG.holyBurstKnockback);
            } else if (isAllyPlayer(player, target)) {
                target.heal(HeavenHell.CONFIG.holyBurstHeal);
                level.sendParticles(ParticleTypes.HEART, target.getX(), target.getY() + 1.0, target.getZ(), 4, 0.35, 0.4, 0.35, 0.02);
            }
        }
        return true;
    }

    private static boolean divineJudgement(ServerPlayer player) {
        LivingEntity target = findLookTarget(player, HeavenHell.CONFIG.divineJudgementRange);
        if (target == null) { fail(player, "Aim at an enemy within 15 blocks."); return false; }
        ServerLevel level = player.level();
        Vec3 mark = target.position();
        target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 24, 0, true, false, true));
        emitJudgementBeam(level, mark);
        level.playSound(null, target.blockPosition(), AbilitySounds.DIVINE_JUDGEMENT, SoundSource.PLAYERS, 1.0f, 1.0f);
        JUDGEMENTS.add(new PendingJudgement(player, target, level, mark, 20));
        return true;
    }

    private static boolean heavensWrath(ServerPlayer player) {
        ServerLevel level = player.level();
        double radius = HeavenHell.CONFIG.heavensWrathRadius;
        level.playSound(null, player.blockPosition(), AbilitySounds.HEAVENS_WRATH, SoundSource.PLAYERS, 1.0f, 1.0f);
        level.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 0.2, player.getZ(), 110, radius / 1.7, 0.7, radius / 1.7, 0.08);
        ZONES.add(new Zone(player, Race.ANGEL, radius, HeavenHell.CONFIG.heavensWrathDurationSeconds * 20));
        return true;
    }

    private static boolean infernalBlast(ServerPlayer player) {
        ServerLevel level = player.level();
        double radius = HeavenHell.CONFIG.infernalBlastRadius;
        level.playSound(null, player.blockPosition(), AbilitySounds.INFERNAL_BLAST, SoundSource.PLAYERS, 1.0f, 1.0f);
        level.sendParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 0.6, player.getZ(), 70, radius / 2.0, 0.35, radius / 2.0, 0.1);
        level.sendParticles(ParticleTypes.EXPLOSION, player.getX(), player.getY() + 0.3, player.getZ(), 1, 0, 0, 0, 0);
        for (LivingEntity target : nearbyLiving(player, radius)) {
            if (isEnemy(player, target)) {
                target.hurt(player.damageSources().playerAttack(player), HeavenHell.CONFIG.infernalBlastDamage);
                target.igniteForSeconds(HeavenHell.CONFIG.infernalBlastFireSeconds);
                pushAway(player, target, HeavenHell.CONFIG.infernalBlastKnockback);
            }
        }
        destroyTerrainCrater(player, HeavenHell.CONFIG.infernalBlastTerrainRadius,
                HeavenHell.CONFIG.infernalBlastTerrainDepth, 36);
        return true;
    }

    private static boolean hellfireChains(ServerPlayer player) {
        LivingEntity target = findLookTarget(player, HeavenHell.CONFIG.hellfireChainsRange);
        if (target == null) {
            player.level().playSound(null, player.blockPosition(), AbilitySounds.HELLFIRE_CHAINS_MISS, SoundSource.PLAYERS, 1.0f, 1.0f);
            fail(player, "Hellfire Chains missed — no clear enemy target.");
            return false;
        }
        ServerLevel level = player.level();
        Vec3 start = player.getEyePosition();
        Vec3 end = target.getEyePosition();
        level.playSound(null, target.blockPosition(), AbilitySounds.HELLFIRE_CHAINS_HIT, SoundSource.PLAYERS, 1.0f, 1.0f);
        emitChain(level, start, end);
        target.hurt(player.damageSources().playerAttack(player), HeavenHell.CONFIG.hellfireChainsDamage);
        target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, HeavenHell.CONFIG.hellfireChainsStunTicks, 6, true, false, true));
        Vec3 pull = player.position().subtract(target.position());
        if (pull.lengthSqr() > 0.0001) {
            Vec3 velocity = pull.normalize().scale(HeavenHell.CONFIG.hellfireChainsPullStrength).add(0, 0.18, 0);
            target.setDeltaMovement(velocity);
            target.hurtMarked = true;
        }
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, target.getX(), target.getY() + 1.0, target.getZ(), 18, 0.25, 0.45, 0.25, 0.04);
        return true;
    }

    private static boolean infernalCataclysm(ServerPlayer player) {
        ServerLevel level = player.level();
        double radius = HeavenHell.CONFIG.infernalCataclysmRadius;
        level.playSound(null, player.blockPosition(), AbilitySounds.INFERNAL_CATACLYSM, SoundSource.PLAYERS, 1.0f, 1.0f);
        level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, player.getX(), player.getY() + 0.2, player.getZ(), 100, radius / 1.7, 0.4, radius / 1.7, 0.08);
        level.sendParticles(ParticleTypes.SMOKE, player.getX(), player.getY() + 0.2, player.getZ(), 45, radius / 1.8, 0.3, radius / 1.8, 0.04);
        destroyTerrainCrater(player, HeavenHell.CONFIG.infernalCataclysmTerrainRadius,
                HeavenHell.CONFIG.infernalCataclysmTerrainDepth, 112);
        ZONES.add(new Zone(player, Race.DEMON, radius, HeavenHell.CONFIG.infernalCataclysmDurationSeconds * 20));
        summonMiniMeteors(player, 8, radius * 0.88);
        return true;
    }

    private static void strikeHolyLightning(Zone zone, ServerPlayer owner, LivingEntity target) {
        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(zone.level, EntitySpawnReason.TRIGGERED);
        if (bolt != null) {
            bolt.setVisualOnly(true);
            bolt.setPos(target.getX(), target.getY(), target.getZ());
            zone.level.addFreshEntity(bolt);
        }
        target.hurt(zone.level.damageSources().magic(), HeavenHell.CONFIG.zoneDamage);
        zone.level.sendParticles(ParticleTypes.ELECTRIC_SPARK, target.getX(), target.getY() + 0.9,
                target.getZ(), 26, 0.42, 0.8, 0.42, 0.12);
    }

    private static void summonMiniMeteors(ServerPlayer owner, int count, double radius) {
        ServerLevel level = owner.level();
        for (int i = 0; i < count; i++) {
            double angle = owner.getRandom().nextDouble() * Math.PI * 2.0;
            double distance = Math.sqrt(owner.getRandom().nextDouble()) * radius;
            int x = (int) Math.floor(owner.getX() + Math.cos(angle) * distance);
            int z = (int) Math.floor(owner.getZ() + Math.sin(angle) * distance);
            BlockPos surface = level.getHeightmapPos(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING,
                    new BlockPos(x, owner.blockPosition().getY(), z));
            Vec3 impact = new Vec3(x + 0.5, surface.getY() + 0.15, z + 0.5);
            METEORS.add(new PendingMeteor(owner.getUUID(), level, impact, 12 + owner.getRandom().nextInt(34)));
        }
    }

    private static void impactMeteor(ServerPlayer owner, PendingMeteor meteor) {
        Vec3 point = meteor.impact;
        double radius = 2.65;
        meteor.level.sendParticles(ParticleTypes.EXPLOSION_EMITTER, point.x, point.y + 0.1, point.z, 1, 0, 0, 0, 0);
        meteor.level.sendParticles(ParticleTypes.FLAME, point.x, point.y + 0.2, point.z, 48, 0.8, 0.35, 0.8, 0.12);
        meteor.level.sendParticles(ParticleTypes.LAVA, point.x, point.y + 0.1, point.z, 12, 0.65, 0.15, 0.65, 0.02);
        meteor.level.sendParticles(ParticleTypes.SMOKE, point.x, point.y + 0.4, point.z, 24, 0.6, 0.35, 0.6, 0.06);
        AABB area = new AABB(point.x - radius, point.y - 1.5, point.z - radius,
                point.x + radius, point.y + 2.5, point.z + radius);
        for (LivingEntity target : meteor.level.getEntitiesOfClass(LivingEntity.class, area,
                e -> e.isAlive() && !(e instanceof ArmorStand)
                        && e.position().distanceToSqr(point) <= radius * radius && isEnemy(owner, e))) {
            target.hurt(owner.damageSources().playerAttack(owner), 10.0f);
            target.igniteForSeconds(4);
            Vec3 away = target.position().subtract(point);
            if (away.lengthSqr() < 0.0001) away = new Vec3(0, 0, 1);
            away = away.normalize();
            target.setDeltaMovement(target.getDeltaMovement().add(away.x * 0.75, 0.35, away.z * 0.75));
            target.hurtMarked = true;
        }
    }

    /**
     * Carves a small, controlled crater without drops. It only removes ordinary, breakable
     * terrain; protected positions, block entities, liquids and hard/valuable blocks are kept.
     */
    private static void destroyTerrainCrater(ServerPlayer owner, int radius, int depth, int maxBlocks) {
        if (!HeavenHell.CONFIG.terrainDestructionEnabled) return;
        ServerLevel level = owner.level();
        int centerX = owner.blockPosition().getX();
        int centerY = owner.blockPosition().getY();
        int centerZ = owner.blockPosition().getZ();
        int destroyed = 0;
        int safeRadius = Math.max(1, Math.min(radius, 6));
        int safeDepth = Math.max(1, Math.min(depth, 4));

        for (int dx = -safeRadius; dx <= safeRadius; dx++) {
            for (int dz = -safeRadius; dz <= safeRadius; dz++) {
                double distance = Math.sqrt(dx * dx + dz * dz);
                if (distance > safeRadius) continue;
                int columnDepth = Math.max(1, safeDepth - (int) Math.floor(distance / safeRadius * safeDepth));
                for (int dy = 0; dy < columnDepth; dy++) {
                    BlockPos pos = new BlockPos(centerX + dx, centerY - 1 - dy, centerZ + dz);
                    var state = level.getBlockState(pos);
                    float hardness = state.getDestroySpeed(level, pos);
                    if (state.isAir() || state.hasBlockEntity() || !state.getFluidState().isEmpty()
                            || hardness < 0.0f || hardness > 2.5f || !level.mayInteract(owner, pos)) continue;
                    level.levelEvent(2001, pos, Block.getId(state));
                    if (level.destroyBlock(pos, false, owner) && ++destroyed >= maxBlocks) return;
                }
            }
        }
    }

    private static LivingEntity findLookTarget(ServerPlayer player, double range) {
        Vec3 start = player.getEyePosition();
        Vec3 end = start.add(player.getLookAngle().scale(range));
        AABB search = player.getBoundingBox().expandTowards(player.getLookAngle().scale(range)).inflate(1.0);
        LivingEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (LivingEntity candidate : player.level().getEntitiesOfClass(LivingEntity.class, search,
                e -> e != player && e.isAlive() && !(e instanceof ArmorStand) && isEnemy(player, e))) {
            Vec3 intercept = candidate.getBoundingBox().inflate(0.35).clip(start, end).orElse(null);
            if (intercept == null) continue;
            double distance = start.distanceToSqr(intercept);
            if (distance >= bestDistance) continue;
            HitResult obstruction = player.level().clip(new ClipContext(start, intercept,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (obstruction.getType() != HitResult.Type.MISS) continue;
            best = candidate;
            bestDistance = distance;
        }
        return best;
    }

    private static List<LivingEntity> nearbyLiving(ServerPlayer player, double radius) {
        AABB box = player.getBoundingBox().inflate(radius);
        return player.level().getEntitiesOfClass(LivingEntity.class, box,
                e -> e != player && e.isAlive() && !(e instanceof ArmorStand)
                        && e.position().distanceToSqr(player.position()) <= radius * radius
                        && (isEnemy(player, e) || isAllyPlayer(player, e)));
    }

    private static boolean isEnemy(ServerPlayer owner, LivingEntity target) {
        // Use the vanilla interaction permission hook before considering an entity attackable.
        // Region/protection mods that integrate this hook can veto ability damage here.
        if (!owner.level().mayInteract(owner, target.blockPosition())) return false;
        if (target instanceof ServerPlayer other) {
            if (other == owner) return false;
            PlayerData ownerData = HeavenHell.DATA.get(owner.getUUID());
            PlayerData targetData = HeavenHell.DATA.get(other.getUUID());
            if (ownerData.race != Race.HUMAN && ownerData.race == targetData.race) return false;
            if (ownerData.race == Race.DEMON && owner.isAlliedTo(other)) return false;
            return HeavenHell.CONFIG.friendlyFire || !owner.isAlliedTo(other);
        }
        return target instanceof Mob mob && mob.getType().getCategory() == MobCategory.MONSTER;
    }

    private static boolean isAllyPlayer(ServerPlayer owner, LivingEntity target) {
        if (!(target instanceof ServerPlayer other)) return false;
        return other == owner || (!HeavenHell.CONFIG.friendlyFire && owner.isAlliedTo(other));
    }

    private static void pushAway(ServerPlayer owner, LivingEntity target, double strength) {
        Vec3 away = target.position().subtract(owner.position());
        if (away.lengthSqr() < 0.0001) away = new Vec3(0, 0, 1);
        away = away.normalize();
        target.setDeltaMovement(target.getDeltaMovement().add(away.x * strength, 0.25, away.z * strength));
        target.hurtMarked = true;
    }

    private static void emitChain(ServerLevel level, Vec3 start, Vec3 end) {
        Vec3 delta = end.subtract(start);
        int steps = Math.max(6, (int) (delta.length() * 2.0));
        for (int i = 0; i <= steps; i++) {
            Vec3 point = start.add(delta.scale(i / (double) steps));
            level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, point.x, point.y, point.z, 2, 0.035, 0.035, 0.035, 0.005);
            if (i % 2 == 0) level.sendParticles(ParticleTypes.CRIT, point.x, point.y, point.z, 1, 0, 0, 0, 0.01);
        }
    }

    private static void tick(MinecraftServer server) {
        Iterator<PendingJudgement> judgementIterator = JUDGEMENTS.iterator();
        while (judgementIterator.hasNext()) {
            PendingJudgement judgement = judgementIterator.next();
            if (--judgement.ticksLeft > 0) continue;
            impactJudgement(judgement);
            judgementIterator.remove();
        }

        Iterator<PendingMeteor> meteorIterator = METEORS.iterator();
        while (meteorIterator.hasNext()) {
            PendingMeteor meteor = meteorIterator.next();
            ServerPlayer owner = server.getPlayerList().getPlayer(meteor.owner);
            PlayerData ownerData = owner == null ? null : HeavenHell.DATA.get(owner.getUUID());
            if (owner == null || !owner.isAlive() || owner.level() != meteor.level
                    || ownerData == null || ownerData.race != Race.DEMON || ownerData.isPowerless()
                    || ownerData.rank() != Rank.DEMON_LORD) {
                meteorIterator.remove();
                continue;
            }
            meteor.ticksLeft--;
            double trailY = meteor.impact.y + Math.max(0.0, meteor.ticksLeft) * 0.68 + 0.8;
            meteor.level.sendParticles(ParticleTypes.FLAME, meteor.impact.x, trailY, meteor.impact.z,
                    10, 0.28, 0.35, 0.28, 0.055);
            meteor.level.sendParticles(ParticleTypes.SMOKE, meteor.impact.x, trailY + 0.25, meteor.impact.z,
                    5, 0.20, 0.25, 0.20, 0.025);
            if (meteor.ticksLeft <= 0) {
                impactMeteor(owner, meteor);
                meteorIterator.remove();
            }
        }

        Iterator<Zone> zoneIterator = ZONES.iterator();
        while (zoneIterator.hasNext()) {
            Zone zone = zoneIterator.next();
            if (--zone.ticksLeft <= 0) {
                zoneIterator.remove();
                continue;
            }
            zone.ticksElapsed++;
            ServerPlayer owner = server.getPlayerList().getPlayer(zone.owner);
            PlayerData ownerData = owner == null ? null : HeavenHell.DATA.get(owner.getUUID());
            if (owner == null || !owner.isAlive() || owner.level() != zone.level
                    || ownerData == null || ownerData.race != zone.race || ownerData.isPowerless()) {
                zoneIterator.remove();
                continue;
            }
            if (zone.ticksElapsed % 10 == 0) zoneParticles(zone);
            if (zone.ticksElapsed % 20 == 0) pulseZone(owner, zone);
        }
    }

    private static void impactJudgement(PendingJudgement judgement) {
        ServerPlayer owner = judgement.owner;
        LivingEntity target = judgement.target;
        PlayerData ownerData = HeavenHell.DATA.get(owner.getUUID());
        if (!owner.isAlive() || owner.isRemoved() || !target.isAlive() || target.isRemoved()
                || owner.level() != judgement.level || target.level() != judgement.level
                || ownerData.race != Race.ANGEL || ownerData.isPowerless() || !isUnlocked(ownerData, 1)) return;
        judgement.level.sendParticles(ColorParticleOption.create(ParticleTypes.FLASH, 0xFFFFFF), judgement.mark.x, judgement.mark.y + 0.6, judgement.mark.z, 1, 0, 0, 0, 0);
        emitJudgementBeam(judgement.level, judgement.mark);
        judgement.level.sendParticles(ParticleTypes.END_ROD, judgement.mark.x, judgement.mark.y + 1.0, judgement.mark.z, 30, 0.5, 0.9, 0.5, 0.12);
        if (target.position().distanceToSqr(judgement.mark) <= 4.0 && isEnemy(owner, target)) {
            target.hurt(owner.damageSources().playerAttack(owner), HeavenHell.CONFIG.divineJudgementDamage);
            target.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, HeavenHell.CONFIG.divineJudgementSlownessTicks, 1, true, false, true));
        }
    }

    private static void emitJudgementBeam(ServerLevel level, Vec3 mark) {
        // A short vertical tracer communicates the marked strike without spawning entities.
        for (int i = 0; i < 9; i++) {
            double y = mark.y + 7.0 - i * 0.72;
            level.sendParticles(ParticleTypes.END_ROD, mark.x, y, mark.z, 2, 0.035, 0.025, 0.035, 0.01);
        }
    }

    private static void zoneParticles(Zone zone) {
        // Two restrained perimeter updates per second keep many simultaneous SMP zones affordable.
        int count = 12;
        for (int i = 0; i < count; i++) {
            double angle = (zone.ticksElapsed * 0.08) + (Math.PI * 2.0 * i / count);
            double x = zone.center.x + Math.cos(angle) * zone.radius;
            double z = zone.center.z + Math.sin(angle) * zone.radius;
            if (zone.race == Race.ANGEL) {
                zone.level.sendParticles(ParticleTypes.END_ROD, x, zone.center.y + 0.2, z, 1, 0.05, 0.5, 0.05, 0.02);
            } else {
                zone.level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, zone.center.y + 0.2, z, 1, 0.08, 0.35, 0.08, 0.01);
                if ((i & 1) == 0) zone.level.sendParticles(ParticleTypes.SMOKE, x, zone.center.y + 0.1, z, 1, 0.04, 0.2, 0.04, 0.005);
            }
        }
    }

    private static void pulseZone(ServerPlayer owner, Zone zone) {
        AABB box = new AABB(zone.center.x - zone.radius, zone.center.y - 2, zone.center.z - zone.radius,
                zone.center.x + zone.radius, zone.center.y + 3, zone.center.z + zone.radius);
        Set<UUID> currentlyInside = new HashSet<>();
        for (LivingEntity entity : zone.level.getEntitiesOfClass(LivingEntity.class, box,
                e -> e.isAlive() && !(e instanceof ArmorStand) && e.position().distanceToSqr(zone.center) <= zone.radius * zone.radius)) {
            if (entity instanceof ServerPlayer player && player != owner && isAllyPlayer(owner, player)) {
                if (zone.race == Race.ANGEL && zone.ticksElapsed % 40 == 0) {
                    player.heal(HeavenHell.CONFIG.zoneAllyHeal);
                }
                currentlyInside.add(player.getUUID());
                continue;
            }
            if (!isEnemy(owner, entity)) continue;
            currentlyInside.add(entity.getUUID());
            if (zone.race == Race.ANGEL) {
                if (!zone.previouslyInside.contains(entity.getUUID())) {
                    entity.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 30, 0, true, false, true));
                }
                strikeHolyLightning(zone, owner, entity);
            } else {
                entity.hurt(owner.damageSources().playerAttack(owner), HeavenHell.CONFIG.zoneDamage);
                entity.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 25, 0, true, false, true));
                if (owner.getRandom().nextFloat() < HeavenHell.CONFIG.cataclysmEruptionChance) {
                    zone.level.sendParticles(ParticleTypes.LAVA, entity.getX(), entity.getY() + 0.05, entity.getZ(), 8, 0.2, 0.05, 0.2, 0.02);
                    zone.level.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, entity.getX(), entity.getY() + 0.1, entity.getZ(), 16, 0.3, 0.25, 0.3, 0.04);
                    zone.level.sendParticles(ParticleTypes.EXPLOSION, entity.getX(), entity.getY() + 0.2, entity.getZ(), 1, 0, 0, 0, 0);
                    entity.igniteForSeconds(2);
                }
            }
        }
        if (zone.race == Race.ANGEL && zone.ticksElapsed % 40 == 0) owner.heal(HeavenHell.CONFIG.zoneAllyHeal);
        zone.previouslyInside.clear();
        zone.previouslyInside.addAll(currentlyInside);
    }

    private static void fail(ServerPlayer player, String message) {
        player.displayClientMessage(Component.literal("§c" + message), true);
    }

    private static String abilityId(int slot) {
        return switch (slot) {
            case 0 -> "holy_burst"; case 1 -> "divine_judgement"; case 2 -> "heavens_wrath";
            case 3 -> "infernal_blast"; case 4 -> "hellfire_chains"; default -> "infernal_cataclysm";
        };
    }

    private static String abilityName(int slot) {
        return switch (slot) {
            case 0 -> "Holy Burst"; case 1 -> "Divine Judgement"; case 2 -> "Heaven's Wrath";
            case 3 -> "Infernal Blast"; case 4 -> "Hellfire Chains"; default -> "Infernal Cataclysm";
        };
    }

    public static int cooldownRemainingSeconds(PlayerData data, int slot) {
        String id = abilityId(slot);
        long usedAt = data.abilityCooldowns.getOrDefault(id, 0L);
        long remaining = cooldown(slot) * 1000L - (System.currentTimeMillis() - usedAt);
        return remaining <= 0 ? 0 : (int) ((remaining + 999L) / 1000L);
    }

    private static int cooldown(int slot) {
        return switch (slot) {
            case 0 -> HeavenHell.CONFIG.holyBurstCooldownSeconds;
            case 1 -> HeavenHell.CONFIG.divineJudgementCooldownSeconds;
            case 2 -> HeavenHell.CONFIG.heavensWrathCooldownSeconds;
            case 3 -> HeavenHell.CONFIG.infernalBlastCooldownSeconds;
            case 4 -> HeavenHell.CONFIG.hellfireChainsCooldownSeconds;
            default -> HeavenHell.CONFIG.infernalCataclysmCooldownSeconds;
        };
    }

    private static final class PendingJudgement {
        final ServerPlayer owner; final LivingEntity target; final ServerLevel level; final Vec3 mark; int ticksLeft;
        PendingJudgement(ServerPlayer owner, LivingEntity target, ServerLevel level, Vec3 mark, int ticksLeft) {
            this.owner = owner; this.target = target; this.level = level; this.mark = mark; this.ticksLeft = ticksLeft;
        }
    }

    private static final class PendingMeteor {
        final UUID owner;
        final ServerLevel level;
        final Vec3 impact;
        int ticksLeft;
        PendingMeteor(UUID owner, ServerLevel level, Vec3 impact, int ticksLeft) {
            this.owner = owner; this.level = level; this.impact = impact; this.ticksLeft = ticksLeft;
        }
    }

    private static final class Zone {
        final UUID owner; final Race race; final ServerLevel level; final Vec3 center; final double radius;
        final Set<UUID> previouslyInside = new HashSet<>(); int ticksLeft; int ticksElapsed;
        Zone(ServerPlayer owner, Race race, double radius, int durationTicks) {
            this.owner = owner.getUUID(); this.race = race; this.level = owner.level();
            this.center = owner.position(); this.radius = radius; this.ticksLeft = durationTicks;
        }
    }
}
