package com.kuku.heavenhell.gameplay;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.data.PlayerData;
import com.kuku.heavenhell.data.Race;
import com.kuku.heavenhell.data.Rank;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.damagesource.DamageSource;

/** Direct-melee passive triggers. Projectile damage is deliberately excluded from hit counters. */
public final class CombatPassives {
    private CombatPassives() {}

    public static void onLivingEntityDamaged(LivingEntity victim, DamageSource source,
                                             float baseDamageTaken, float damageTaken, boolean blocked) {
        if (blocked || damageTaken <= 0.0f) return;
        Entity attackerEntity = source.getEntity();
        if (!(attackerEntity instanceof ServerPlayer attacker) || source.getDirectEntity() != attacker) return;
        if (victim == attacker || !victim.isAlive()) return;
        if (victim instanceof ServerPlayer ally && !HeavenHell.CONFIG.friendlyFire
                && attacker.isAlliedTo(ally)) return;

        PlayerData data = HeavenHell.DATA.get(attacker.getUUID());
        if (data.race != Race.DEMON || data.isPowerless()) return;
        Rank rank = data.rank();
        if (!isDemonRank(rank)) return;

        if (HeavenHell.CONFIG.demonEmberbornChancePercent > 0
                && attacker.getRandom().nextInt(100) < HeavenHell.CONFIG.demonEmberbornChancePercent) {
            victim.igniteForSeconds(2.0f);
        }

        if (rank == Rank.ARCHDEMON || rank == Rank.DEMON_LORD) {
            long gameTime = attacker.level().getServer().overworld().getGameTime();
            data.bloodthirstHitCount++;
            int needed = HeavenHell.CONFIG.demonBloodthirstRequiredHits;
            long cooldownTicks = HeavenHell.CONFIG.demonBloodthirstCooldownSeconds * 20L;
            if (data.bloodthirstHitCount >= needed
                    && gameTime - data.lastBloodthirstProcGameTime >= cooldownTicks) {
                data.bloodthirstHitCount = 0;
                data.lastBloodthirstProcGameTime = gameTime;
                float before = attacker.getHealth();
                attacker.heal(HeavenHell.CONFIG.demonBloodthirstHeal);
                if (attacker.getHealth() > before) {
                    attacker.level().sendParticles(net.minecraft.core.particles.ParticleTypes.DAMAGE_INDICATOR,
                            attacker.getX(), attacker.getY() + 1.0, attacker.getZ(), 5, 0.25, 0.35, 0.25, 0.0);
                    if (HeavenHell.CONFIG.actionBarNotifications) {
                        attacker.displayClientMessage(net.minecraft.network.chat.Component.literal("§cBloodthirst: §f+"
                                + Math.round((attacker.getHealth() - before) * 10.0f) / 10.0f + " HP"), true);
                    }
                }
                HeavenHell.DATA.save();
            }
        }
    }

    private static boolean isDemonRank(Rank rank) {
        return rank == Rank.LESSER_DEMON || rank == Rank.ARCHDEMON || rank == Rank.DEMON_LORD;
    }
}
