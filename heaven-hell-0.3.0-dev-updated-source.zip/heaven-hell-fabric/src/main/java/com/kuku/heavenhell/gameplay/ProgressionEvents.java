package com.kuku.heavenhell.gameplay;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.api.KarmaEvent;
import com.kuku.heavenhell.api.KarmaService;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.LivingEntity;
import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

/** Hooks vanilla combat outcomes into the central karma API. All rewards are decided server-side. */
public final class ProgressionEvents {
    private static final Set<Entity> NO_KARMA_REWARD = Collections.synchronizedSet(
            Collections.newSetFromMap(new WeakHashMap<>()));

    private ProgressionEvents() {}

    public static void register() {
        ServerLivingEntityEvents.AFTER_DEATH.register(ProgressionEvents::onDeath);
        ServerLivingEntityEvents.AFTER_DAMAGE.register(CombatPassives::onLivingEntityDamaged);
    }

    /** Mark a mob spawned by a player or an integration as ineligible for kill-karma rewards. */
    public static void markNoKarmaReward(Entity entity) {
        if (entity != null) NO_KARMA_REWARD.add(entity);
    }

    private static void onDeath(LivingEntity dead, net.minecraft.world.damagesource.DamageSource source) {
        Entity responsible = source.getEntity();
        if (!(responsible instanceof ServerPlayer killer)) return;
        if (dead instanceof ServerPlayer victim) {
            KarmaService.award(killer, victim, KarmaEvent.PLAYER_KILL);
            return;
        }
        if (!(dead instanceof Mob mob) || NO_KARMA_REWARD.remove(mob)) return;
        // Persistence-required mobs are commonly created by commands, spawn eggs, or plugins.
        // They are excluded by default to make the most obvious summon loops unrewarding.
        if (mob.isPersistenceRequired()) return;
        MobCategory category = mob.getType().getCategory();
        if (category == MobCategory.MONSTER) {
            KarmaService.award(killer, null, KarmaEvent.HOSTILE_MOB_KILL);
        } else if (category == MobCategory.CREATURE || category == MobCategory.AMBIENT
                || category == MobCategory.AXOLOTLS || category == MobCategory.UNDERGROUND_WATER_CREATURE
                || category == MobCategory.WATER_CREATURE || category == MobCategory.WATER_AMBIENT) {
            KarmaService.award(killer, null, KarmaEvent.PASSIVE_MOB_KILL);
        }
    }
}
