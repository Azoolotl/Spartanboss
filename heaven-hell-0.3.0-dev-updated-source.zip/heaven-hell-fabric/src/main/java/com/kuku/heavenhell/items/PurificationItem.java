package com.kuku.heavenhell.items;

import com.kuku.heavenhell.HeavenHell;
import com.kuku.heavenhell.data.PlayerData;
import com.kuku.heavenhell.data.Race;
import com.kuku.heavenhell.gameplay.ActiveAbilityService;
import com.kuku.heavenhell.network.StatusSync;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Deliberate two-use confirmation prevents accidental consumption of a very expensive reset item.
 * Confirmation is server-side, bound to the race-specific artifact, and expires after the server-configured confirmation window.
 */
public final class PurificationItem extends Item {
    private static final Map<UUID, PendingConfirmation> PENDING = new ConcurrentHashMap<>();

    private final Race raceToRemove;

    public PurificationItem(Properties properties, Race raceToRemove) {
        super(properties);
        if (raceToRemove != Race.ANGEL && raceToRemove != Race.DEMON) {
            throw new IllegalArgumentException("Purification can only remove an Angel or Demon race lock");
        }
        this.raceToRemove = raceToRemove;
    }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(player instanceof ServerPlayer serverPlayer)) {
            // The server performs all validation, state mutation, and item consumption.
            return InteractionResult.SUCCESS;
        }

        if (!HeavenHell.CONFIG.purificationEnabled) {
            serverPlayer.displayClientMessage(Component.literal("§cPurification artifacts are disabled by the server."), true);
            return InteractionResult.FAIL;
        }
        ItemStack stack = serverPlayer.getItemInHand(hand);
        PlayerData data = HeavenHell.DATA.get(serverPlayer.getUUID());
        if (data.race != raceToRemove) {
            PENDING.remove(serverPlayer.getUUID());
            serverPlayer.displayClientMessage(Component.literal(raceToRemove == Race.ANGEL
                    ? "§cDivine Purification can only be used by an Angel."
                    : "§cInfernal Purification can only be used by a Demon."), true);
            return InteractionResult.FAIL;
        }

        long now = serverPlayer.level().getGameTime();
        PendingConfirmation pending = PENDING.get(serverPlayer.getUUID());
        if (pending == null || pending.item != this || now > pending.expiresAtTick) {
            PENDING.put(serverPlayer.getUUID(), new PendingConfirmation(this, now + HeavenHell.CONFIG.purificationConfirmSeconds * 20L));
            serverPlayer.displayClientMessage(Component.literal("§eUse this artifact again within " + HeavenHell.CONFIG.purificationConfirmSeconds + " seconds to confirm purification. Your race and karma will be reset."), false);
            return InteractionResult.SUCCESS;
        }

        PENDING.remove(serverPlayer.getUUID());
        data.purify();
        if (!serverPlayer.isCreative()) stack.shrink(1);
        ActiveAbilityService.onRaceReset(serverPlayer.getUUID());
        HeavenHell.DATA.save();
        StatusSync.broadcast(serverPlayer);
        serverPlayer.displayClientMessage(Component.literal("§a✦ Purification complete. You are Human again, and your karma has returned to zero."), false);
        return InteractionResult.SUCCESS;
    }

    public static void clearPending(UUID playerId) { PENDING.remove(playerId); }

    private record PendingConfirmation(PurificationItem item, long expiresAtTick) {}
}
