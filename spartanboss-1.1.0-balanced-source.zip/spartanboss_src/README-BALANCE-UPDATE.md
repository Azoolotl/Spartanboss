# SpartanBoss 1.1.0 — Balance and Legendary Weapon Update

This source project contains the requested Kratos/Gabriel multiplayer balance update and the six legendary weapon abilities.

## Target environment

- Minecraft Java Edition 1.21.11
- Java 21
- Fabric Loader 0.19.2 or newer
- Fabric API 0.141.4+1.21.11
- GeckoLib 5.4.5 for the development compile (runtime metadata accepts 5.4.0 or newer)
- Fabric Loom 1.14-SNAPSHOT (as configured by the existing project)

## Legendary weapon abilities

The existing registered item IDs, models, textures, and GeckoLib assets are retained. Each weapon has exactly two selectable active abilities. Sneak + right-click switches the selected ability; right-click activates it.

| Existing item | Ability | Cooldown |
|---|---|---:|
| `frost_axe` | Frost Dominion | 40 seconds |
| `frost_axe` | Glacial Spikes | 50 seconds |
| `chaos_blades` | Chaotic Chain Slash | 40 seconds |
| `chaos_blades` | Spartan Fury | 50 seconds |
| `sacred_dual_blades` | Divine Dash | 20 seconds |
| `sacred_dual_blades` | Divine Descent | 50 seconds |

Divine Descent uses Gabriel's existing 22 HP base crash-damage constant and the same ultimate-tier armor interaction as his boss crash (without the boss-only party damage multiplier). The original item ID `sacred_dual_blades` is deliberately preserved to avoid breaking existing item references and saves.

Cooldowns are tracked per player and ability, not only on an individual item stack, so swapping to a duplicate weapon stack does not reset an active cooldown. Spartan Fury lasts 8 seconds; Chaotic Chain Slash performs exactly three strikes (7/7/9 base damage); Frost Dominion stuns ordinary targets for 5 seconds; Glacial Spikes last 6 seconds and apply Slowness II on contact. Divine Dash travels up to 15 blocks. Divine Descent provides 5 seconds of controlled flight before its forced crash.

## Boss balance

- Base health at 5 nearby combat participants: 1000 HP.
- Additional health: 75 HP per participant above 5, capped at 10 participants / 1375 HP.
- Outgoing boss damage multiplier: +3% per participant above 5, capped at 10 participants / 1.15x.
- Participants are alive, non-creative, non-spectator players within 64 blocks of the boss.
- Both bosses use chaotic target selection with a 40–100 tick retarget interval.
- Kratos gives a one-second visual/audio warning before Spartan Rage. Gabriel marks his 7-block crash radius before impact.
- Frost Dominion stuns ordinary targets for 5 seconds; Kratos and Gabriel receive 2.5 seconds of boss stun resistance.
- Both bosses: armor 13, knockback resistance 80%, regeneration 0.5 HP/second.
- Kratos: base attack damage 10.5; Rage starts at 50% HP, lasts 10 seconds, with 75-second Phase 1 and 65-second Phase 2 cooldown values.
- Gabriel: base attack damage 11; movement speed 0.35 (0.40 in Phase 2); follow range 40; aerial combat retained.
- Boss normal/heavy/ultimate attacks use 0%/20%/35% temporary armor reduction respectively while retaining normal damage sources and other defenses.

## Build

From the project root, use Java 21 and a Gradle installation compatible with Fabric Loom 1.14:

```bash
gradle build
```

The compiled mod JAR is written under `build/libs/`. The Gradle project now declares GeckoLib’s Fabric artifact and Maven repository explicitly.

## Verification status

The source and resource JSON files were statically inspected. A Java parser pass found no syntax-level diagnostics, but this environment did not have Gradle, the Minecraft/Fabric/GeckoLib compile classpath, or network access to retrieve them. Therefore a full Gradle compilation and in-game test have **not** been completed here. Build and run the project in the target Minecraft/Fabric environment before distributing the JAR.
