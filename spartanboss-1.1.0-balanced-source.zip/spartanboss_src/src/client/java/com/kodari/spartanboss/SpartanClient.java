package com.kodari.spartanboss;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.BlockRenderLayer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.GeoItemRenderer;
import software.bernie.geckolib.renderer.layer.builtin.ItemInHandGeoLayer;

public class SpartanClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.putBlock(SpartanBoss.TEMPORARY_FIRE, BlockRenderLayer.CUTOUT);
        SacredBladesItem.rendererFactory = (item, consumer) -> consumer.accept(new GeoRenderProvider() {
            private GeoItemRenderer<?> renderer;
            @Override public GeoItemRenderer<?> getGeoItemRenderer() {
                if (renderer == null) renderer = new GeoItemRenderer<>(item);
                return renderer;
            }
        });
        EntityRendererRegistry.register(SpartanBoss.BOSS, Renderer::new);
        EntityRendererRegistry.register(SpartanBoss.GABRIEL, GabrielRenderer::new);
        EntityRendererRegistry.register(SpartanBoss.PROJECTILE, context -> new FlyingItemEntityRenderer<>(context, 1.0f, true));
    }

    public static class Renderer extends GeoEntityRenderer<SpartanEntity, LivingEntityRenderState> {
        public Renderer(EntityRendererFactory.Context context) {
            super(context, SpartanBoss.BOSS);
            withRenderLayer(new ItemInHandGeoLayer<>(this, "forearm_fist_east", "forearm_fist_west"));
        }

        @Override public int getRenderColor(SpartanEntity entity, Void related, float partialTick) {
            return entity.isRaging() ? 0xFFFF6666 : super.getRenderColor(entity, related, partialTick);
        }
    }

    public static class GabrielRenderer extends GeoEntityRenderer<GabrielEntity, LivingEntityRenderState> {
        public GabrielRenderer(EntityRendererFactory.Context context) {
            super(context, SpartanBoss.GABRIEL);
            withRenderLayer(new ItemInHandGeoLayer<>(this, "gauntlet_east", "gauntlet_west"));
        }
    }
}