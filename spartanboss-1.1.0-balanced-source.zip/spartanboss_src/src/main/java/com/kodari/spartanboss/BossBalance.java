package com.kodari.spartanboss;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;

/**
 * Shared multiplayer balance and damage helpers for both bosses.
 * All calculations are performed server-side.
 */
public final class BossBalance {
    public enum AttackTier {
        NORMAL(0.0),
        HEAVY(0.20),
        ULTIMATE(0.35);

        private final double armorPenetration;

        AttackTier(double armorPenetration) {
            this.armorPenetration = armorPenetration;
        }
    }

    public static final double PARTICIPANT_RANGE = 64.0;
    private static final Identifier HEAVY_PIERCE_ID = Identifier.of(SpartanBoss.ID, "heavy_armor_penetration");
    private static final Identifier ULTIMATE_PIERCE_ID = Identifier.of(SpartanBoss.ID, "ultimate_armor_penetration");

    private BossBalance() {
        throw new AssertionError();
    }

    public static int countParticipants(MobEntity boss, ServerWorld world) {
        double rangeSquared = PARTICIPANT_RANGE * PARTICIPANT_RANGE;
        int count = 0;
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (!isEligibleParticipant(player)) continue;
            if (player.squaredDistanceTo(boss) <= rangeSquared) count++;
        }
        return count;
    }

    private static boolean isEligibleParticipant(PlayerEntity player) {
        return player.isAlive() && !player.isCreative() && !player.isSpectator();
    }

    public static double healthForParticipants(int participants) {
        int scaledCount = Math.max(5, Math.min(10, participants));
        return 1000.0 + (75.0 * (scaledCount - 5));
    }

    public static double damageMultiplier(int participants) {
        int scaledCount = Math.max(5, Math.min(10, participants));
        return 1.0 + (0.03 * (scaledCount - 5));
    }

    public static void updateBossAttributes(MobEntity boss, int participants, double baseDamage) {
        double desiredMaxHealth = healthForParticipants(participants);
        EntityAttributeInstance maxHealth = boss.getAttributeInstance(EntityAttributes.MAX_HEALTH);
        if (maxHealth != null && Math.abs(maxHealth.getValue() - desiredMaxHealth) > 0.01) {
            float oldMax = boss.getMaxHealth();
            float oldHealth = boss.getHealth();
            double healthRatio = oldMax <= 0 ? 1.0 : Math.max(0.0, Math.min(1.0, oldHealth / oldMax));
            maxHealth.setBaseValue(desiredMaxHealth);
            boss.setHealth((float) (boss.getMaxHealth() * healthRatio));
        }

        EntityAttributeInstance attack = boss.getAttributeInstance(EntityAttributes.ATTACK_DAMAGE);
        if (attack != null) attack.setBaseValue(baseDamage * damageMultiplier(participants));

        EntityAttributeInstance armor = boss.getAttributeInstance(EntityAttributes.ARMOR);
        if (armor != null) armor.setBaseValue(13.0);

    }

    public static PlayerEntity chooseChaoticTarget(MobEntity boss, ServerWorld world, double range) {
        double rangeSquared = range * range;
        List<ServerPlayerEntity> candidates = new ArrayList<>();
        for (ServerPlayerEntity player : world.getPlayers()) {
            if (isEligibleParticipant(player) && player.squaredDistanceTo(boss) <= rangeSquared) {
                candidates.add(player);
            }
        }
        if (candidates.isEmpty()) return null;

        LivingEntity current = boss.getTarget();
        if (candidates.size() > 1) {
            candidates.removeIf(player -> player == current);
        }
        return candidates.get(boss.getRandom().nextInt(candidates.size()));
    }

    /**
     * Applies a boss attack with party damage scaling and temporary armor reduction.
     * Enchantment protection, Resistance, absorption and other normal defensive systems
     * remain active because the original damage source is retained.
     */
    public static boolean applyBossDamage(ServerWorld world, Entity attacker, LivingEntity target,
                                          DamageSource source, float baseDamage, AttackTier tier) {
        int participants = attacker instanceof MobEntity mob ? countParticipants(mob, world) : 5;
        float damage = (float) (baseDamage * damageMultiplier(participants));
        return applyTieredDamage(world, target, source, damage, tier);
    }

    public static boolean applyTieredDamage(ServerWorld world, LivingEntity target, DamageSource source,
                                            float damage, AttackTier tier) {
        if (tier.armorPenetration <= 0.0 || source.isIn(DamageTypeTags.BYPASSES_ARMOR)) {
            return target.damage(world, source, damage);
        }

        EntityAttributeInstance armor = target.getAttributeInstance(EntityAttributes.ARMOR);
        if (armor == null) return target.damage(world, source, damage);

        Identifier modifierId = tier == AttackTier.ULTIMATE ? ULTIMATE_PIERCE_ID : HEAVY_PIERCE_ID;
        EntityAttributeModifier modifier = new EntityAttributeModifier(
            modifierId, -tier.armorPenetration, EntityAttributeModifier.Operation.ADD_MULTIPLIED_TOTAL
        );

        armor.removeModifier(modifierId);
        armor.addTemporaryModifier(modifier);
        try {
            return target.damage(world, source, damage);
        } finally {
            armor.removeModifier(modifierId);
        }
    }
}
