package com.kodari.spartanboss;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.block.Blocks;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

public class GabrielEntity extends HostileEntity implements GeoEntity {
    public static final float CRASH_BASE_DAMAGE = 22.0f;
    private static final TrackedData<Boolean> FLYING = DataTracker.registerData(GabrielEntity.class, TrackedDataHandlerRegistry.BOOLEAN);
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossBar bar = new ServerBossBar(Text.literal("Gabriel, The Judge of Heaven"), BossBar.Color.YELLOW, BossBar.Style.PROGRESS);
    private final int[] abilityCooldowns = new int[6];
    private boolean phaseTwo;
    private int attackCooldown = 100;
    private int flightCooldown = 200;
    private int flightTicks;
    private boolean crashing;
    private int crashTicks;
    private int sequence;
    private int sequenceAge;
    private int sequenceDuration;
    private LivingEntity sequenceTarget;
    private double markedX;
    private double markedY;
    private double markedZ;
    private int lastParticipantCount = -1;
    private int targetSwitchCooldown;

    public GabrielEntity(EntityType<? extends GabrielEntity> type, World world) {
        super(type, world);
        setPersistent();
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0);
        setEquipmentDropChance(EquipmentSlot.OFFHAND, 0);
    }

    @Override protected void initDataTracker(DataTracker.Builder builder) {
        super.initDataTracker(builder);
        builder.add(FLYING, false);
    }

    public boolean isFlying() { return getDataTracker().get(FLYING); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH, 1000)
            .add(EntityAttributes.ATTACK_DAMAGE, 11).add(EntityAttributes.ARMOR, 13)
            .add(EntityAttributes.MOVEMENT_SPEED, 0.35).add(EntityAttributes.FOLLOW_RANGE, 40)
            .add(EntityAttributes.KNOCKBACK_RESISTANCE, 0.8).add(EntityAttributes.EXPLOSION_KNOCKBACK_RESISTANCE, 0.8);
    }

    @Override protected void initGoals() {
        goalSelector.add(1, new MeleeAttackGoal(this, 1.3, false) {
            @Override public boolean canStart() { return !isFlying() && !crashing && super.canStart(); }
            @Override public boolean shouldContinue() { return !isFlying() && !crashing && super.shouldContinue(); }
        });
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override protected void mobTick(ServerWorld world) {
        super.mobTick(world);
        if (WeaponAbilityManager.isStunned(this)) {
            bar.setPercent(getHealth() / getMaxHealth());
            return;
        }
        if (age % 20 == 0 || lastParticipantCount < 0) {
            int participants = BossBalance.countParticipants(this, world);
            if (participants != lastParticipantCount) {
                BossBalance.updateBossAttributes(this, participants, 11.0);
                lastParticipantCount = participants;
                applyPhaseSpeed();
            }
        }
        if (targetSwitchCooldown > 0) targetSwitchCooldown--;
        if (targetSwitchCooldown <= 0) {
            PlayerEntity chaoticTarget = BossBalance.chooseChaoticTarget(this, world, 40.0);
            setTarget(chaoticTarget);
            targetSwitchCooldown = 40 + getRandom().nextInt(61);
        }
        if (!phaseTwo && getHealth() <= getMaxHealth() * 0.5f) {
            phaseTwo = true;
            applyPhaseSpeed();
            bar.setName(Text.literal("Gabriel – Wrath of Heaven"));
            world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 100, 1, 1, 1, 0.12);
            playSound(SpartanBoss.DIVINE_SOUND, 2, 0.8f);
        }
        if (age % 20 == 0 && getHealth() < getMaxHealth()) heal(0.5f);
        bar.setPercent(getHealth() / getMaxHealth());
        if (age % 10 == 0) {
            breakCobwebs(world);
            if (!getEquippedStack(EquipmentSlot.MAINHAND).isOf(SpartanBoss.BLADES)) equipStack(EquipmentSlot.MAINHAND, new ItemStack(SpartanBoss.BLADES));
            if (!getEquippedStack(EquipmentSlot.OFFHAND).isOf(SpartanBoss.BLADES)) equipStack(EquipmentSlot.OFFHAND, new ItemStack(SpartanBoss.BLADES));
        }
        if (age % 5 == 0) world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), phaseTwo ? 8 : 3, 0.6, 0.8, 0.6, 0.02);
        if (attackCooldown > 0) attackCooldown--;
        if (flightCooldown > 0) flightCooldown--;
        for (int i = 0; i < abilityCooldowns.length; i++) if (abilityCooldowns[i] > 0) abilityCooldowns[i]--;

        LivingEntity target = getTarget();
        if (flightTicks > 0) {
            tickFlight(world, target);
            return;
        }
        if (crashing) {
            tickCrash(world);
            return;
        }
        if (hasNoGravity()) setNoGravity(false);
        if (sequence != 0) {
            tickSequence(world);
            return;
        }
        if (target == null || !target.isAlive()) return;
        if (flightCooldown == 0 && isOnGround()) {
            beginFlight();
            return;
        }
        if (attackCooldown > 0) return;
        List<Integer> available = new ArrayList<>();
        for (int i = 0; i < abilityCooldowns.length; i++) if (abilityCooldowns[i] == 0) available.add(i);
        if (available.isEmpty()) {
            attackCooldown = 30;
            return;
        }
        int choice = available.get(getRandom().nextInt(available.size()));
        abilityCooldowns[choice] = phaseTwo ? 320 : 440;
        attackCooldown = phaseTwo ? 90 : 120;
        useAbility(world, target, choice);
    }

    private void beginFlight() {
        flightTicks = 100;
        getDataTracker().set(FLYING, true);
        setNoGravity(true);
        getNavigation().stop();
        setVelocity(0, 0.65, 0);
        velocityDirty = true;
        fallDistance = 0;
        playSound(SpartanBoss.DIVINE_SOUND, 2, 1.3f);
    }

    private void tickFlight(ServerWorld world, LivingEntity target) {
        getNavigation().stop();
        fallDistance = 0;
        int elapsed = 101 - flightTicks;
        flightTicks--;
        if (target == null || !target.isAlive()) flightTicks = 0;
        if (flightTicks == 0) {
            getDataTracker().set(FLYING, false);
            setNoGravity(false);
            // Mark the seven-block crash radius on the ground before the dive lands.
            BlockPos landing = world.getTopPosition(Heightmap.Type.MOTION_BLOCKING, getBlockPos());
            double markerY = landing.getY() + 0.06;
            for (int i = 0; i < 56; i++) {
                double angle = Math.PI * 2.0 * i / 56.0;
                double markerX = getX() + Math.cos(angle) * 7.0;
                double markerZ = getZ() + Math.sin(angle) * 7.0;
                world.spawnParticles(new DustParticleEffect(0xFFF0A0, 1.35f), markerX, markerY, markerZ,
                    2, 0.025, 0.025, 0.025, 0.0);
            }
            world.spawnParticles(ParticleTypes.FLASH, getX(), markerY + 0.15, getZ(), 1, 0, 0, 0, 0);
            playSound(SpartanBoss.DIVINE_SOUND, 2.0f, 1.2f);
            crashing = true;
            crashTicks = 0;
            setVelocity(getVelocity().x * 0.35, -1.35, getVelocity().z * 0.35);
            velocityDirty = true;
            triggerAnim("movement", "dive");
            return;
        }
        double angle = elapsed * 0.13;
        boolean swooping = (elapsed >= 28 && elapsed <= 42) || (elapsed >= 65 && elapsed <= 79);
        double radius = swooping ? 1.2 : 4.0;
        Vec3d destination = target.getEntityPos().add(Math.cos(angle) * radius, swooping ? 2.1 : 5.0, Math.sin(angle) * radius);
        Vec3d offset = destination.subtract(getEntityPos());
        Vec3d velocity = offset.normalize().multiply(Math.min(swooping ? 0.85 : 0.55, offset.length() * 0.15));
        setVelocity(velocity);
        velocityDirty = true;
        world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 5, 0.5, 0.5, 0.5, 0.04);
        if (elapsed == 28 || elapsed == 65) triggerAnim("movement", "dive");
        if ((elapsed == 40 || elapsed == 77) && distanceTo(target) < 4) strike(world, getX(), getY(), getZ(), 4, 15, 0.8);
        if (elapsed == 18 || elapsed == 57) shoot(world, target, CombatProjectileEntity.SPEAR, phaseTwo ? 25 : 22);
    }

    private void tickCrash(ServerWorld world) {
        getNavigation().stop();
        setNoGravity(false);
        fallDistance = 0;
        crashTicks++;
        if (crashTicks > 2 && isOnGround()) {
            crashing = false;
            flightCooldown = phaseTwo ? 720 : 800;
            attackCooldown = Math.max(attackCooldown, 30);
            strike(world, getX(), getY(), getZ(), 7, CRASH_BASE_DAMAGE, 1.4, BossBalance.AttackTier.ULTIMATE);
            ArenaEffects.explosion(world, this, phaseTwo ? 4.2f : 3.8f);
            world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, getX(), getY() + 0.5, getZ(), 1, 0, 0, 0, 0);
            world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1, getZ(), 100, 2.5, 1, 2.5, 0.15);
            playSound(SpartanBoss.CRASH_SOUND, 2.5f, 0.8f);
        }
    }

    private void useAbility(ServerWorld world, LivingEntity target, int choice) {
        switch (choice) {
            case 0 -> {
                triggerAnim("movement", "spear");
                shoot(world, target, CombatProjectileEntity.SPEAR, phaseTwo ? 26 : 22);
            }
            case 1 -> {
                markedX = target.getX();
                markedY = target.getY();
                markedZ = target.getZ();
                startSequence(1, 35, target);
                triggerAnim("movement", "judgment");
                playSound(SpartanBoss.DIVINE_SOUND, 1.8f, 0.8f);
            }
            case 2 -> {
                startSequence(2, 36, target);
                triggerAnim("movement", "barrage");
            }
            case 3 -> {
                Vec3d facing = target.getRotationVec(1);
                Vec3d behind = target.getEntityPos().subtract(new Vec3d(facing.x, 0, facing.z).normalize().multiply(2.2));
                Box destination = getBoundingBox().offset(behind.subtract(getEntityPos()));
                if (world.isSpaceEmpty(this, destination) && !world.getBlockState(BlockPos.ofFloored(behind.x, behind.y - 0.1, behind.z)).isAir()) {
                    requestTeleport(behind.x, behind.y, behind.z);
                }
                startSequence(3, 36, target);
                triggerAnim("movement", "execution");
                playSound(SpartanBoss.DIVINE_SOUND, 1.5f, 1.6f);
            }
            case 4 -> {
                triggerAnim("movement", "crossfire");
                ArenaEffects.crossfire(world, this, target.getEyePos().subtract(getEyePos()), phaseTwo ? 20 : 16);
            }
            case 5 -> {
                Vec3d direction = target.getEntityPos().subtract(getEntityPos()).normalize();
                setVelocity(direction.x * 1.3, 0.25, direction.z * 1.3);
                velocityDirty = true;
                startSequence(4, 30, target);
                triggerAnim("movement", "attack");
            }
            default -> throw new IllegalArgumentException("Unknown combat ability");
        }
    }

    private void startSequence(int ability, int duration, LivingEntity target) {
        sequence = ability;
        sequenceAge = 0;
        sequenceDuration = duration;
        sequenceTarget = target;
    }

    private void tickSequence(ServerWorld world) {
        sequenceAge++;
        LivingEntity target = sequenceTarget;
        if (sequence == 1) {
            for (int i = 0; i < 16; i++) {
                double angle = i * Math.PI / 8;
                world.spawnParticles(new DustParticleEffect(0xFFD44A, 1.3f), markedX + Math.cos(angle) * 2,
                    markedY + 0.2, markedZ + Math.sin(angle) * 2, 1, 0.02, 0.02, 0.02, 0);
            }
            if (sequenceAge == 35) {
                for (int y = 0; y < 16; y++) world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, markedX, markedY + y, markedZ, 4, 0.3, 0.3, 0.3, 0.05);
                strike(world, markedX, markedY, markedZ, 4, 24, 1.0, BossBalance.AttackTier.ULTIMATE);
                ArenaEffects.explosionAt(world, this, markedX, markedY, markedZ, 3.0f);
                playSound(SoundEvents.ENTITY_LIGHTNING_BOLT_THUNDER, 2, 1.2f);
            }
        } else if (sequence == 2 && target != null && target.isAlive() && sequenceAge % 6 == 0) {
            shoot(world, target, CombatProjectileEntity.BOLT, phaseTwo ? 9 : 7);
        } else if ((sequence == 3 || sequence == 4) && sequenceAge % 12 == 0) {
            strike(world, getX(), getY(), getZ(), sequence == 3 ? 4 : 5,
                sequence == 3 ? 8 : 7, 0.4, BossBalance.AttackTier.HEAVY);
            if (sequence == 3) triggerAnim("movement", "execution");
            if (sequence == 3 && sequenceAge == 36) ArenaEffects.explosion(world, this, 2.0f);
        }
        if (sequenceAge >= sequenceDuration) {
            sequence = 0;
            sequenceTarget = null;
        }
    }

    private void shoot(ServerWorld world, LivingEntity target, int kind, float damage) {
        ItemStack visual = kind == CombatProjectileEntity.SPEAR ? new ItemStack(SpartanBoss.BLADES) : new ItemStack(Items.GOLD_NUGGET);
        CombatProjectileEntity.launch(world, this, visual, kind, target.getEyePos().subtract(getEyePos()), damage);
        world.spawnParticles(ParticleTypes.END_ROD, getX(), getY() + 1.5, getZ(), 16, 0.4, 0.4, 0.4, 0.08);
        playSound(SpartanBoss.DIVINE_SOUND, 1, 1.5f);
    }

    private void strike(ServerWorld world, double x, double y, double z, double radius, float damage, double knockback) {
        strike(world, x, y, z, radius, damage, knockback, BossBalance.AttackTier.HEAVY);
    }

    private void strike(ServerWorld world, double x, double y, double z, double radius, float damage,
                        double knockback, BossBalance.AttackTier tier) {
        world.spawnParticles(ParticleTypes.END_ROD, x, y + 1, z, 80, radius / 2, 1, radius / 2, 0.1);
        Box box = new Box(x - radius, y - radius, z - radius, x + radius, y + radius, z + radius);
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, box, p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            double dx = player.getX() - x, dy = player.getY() - y, dz = player.getZ() - z;
            if (dx * dx + dy * dy + dz * dz > radius * radius) continue;
            BossBalance.applyBossDamage(world, this, player, getDamageSources().mobAttack(this),
                damage * (phaseTwo ? 1.2f : 1), tier);
            Vec3d direction = new Vec3d(dx, 0, dz).normalize();
            player.setVelocity(direction.x * knockback, 0.35, direction.z * knockback);
            player.velocityDirty = true;
        }
    }

    private void breakCobwebs(ServerWorld world) {
        for (BlockPos pos : BlockPos.iterateOutwards(getBlockPos(), 1, 2, 1)) {
            if (world.getBlockState(pos).isOf(Blocks.COBWEB) && getBoundingBox().intersects(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1)) world.breakBlock(pos, true, this, 512);
        }
    }

    private void applyPhaseSpeed() {
        EntityAttributeInstance speed = getAttributeInstance(EntityAttributes.MOVEMENT_SPEED);
        if (speed != null) speed.setBaseValue(phaseTwo ? 0.40 : 0.35);
    }

    @Override protected float modifyAppliedDamage(DamageSource source, float amount) {
        float reduced = super.modifyAppliedDamage(source, amount);
        return source.isIn(DamageTypeTags.BYPASSES_EFFECTS) || source.isIn(DamageTypeTags.BYPASSES_ENCHANTMENTS)
            ? reduced : DamageUtil.getInflictedDamage(reduced, 13);
    }

    @Override public boolean handleFallDamage(double distance, float multiplier, DamageSource source) { return false; }
    @Override public void onDeath(DamageSource source) {
        if (!getEntityWorld().isClient()) {
            triggerAnim("movement", "death");
            dropItem(new ItemStack(SpartanBoss.BLADES), true, false);
            dropItem(new ItemStack(SpartanBoss.BLADES), true, false);
        }
        super.onDeath(source);
    }
    @Override public boolean tryAttack(ServerWorld world, Entity target) {
        triggerAnim("movement", "attack");
        return super.tryAttack(world, target);
    }
    @Override public void onStartedTrackingBy(ServerPlayerEntity player) { super.onStartedTrackingBy(player); bar.addPlayer(player); }
    @Override public void onStoppedTrackingBy(ServerPlayerEntity player) { super.onStoppedTrackingBy(player); bar.removePlayer(player); }
    @Override protected void readCustomData(ReadView view) {
        super.readCustomData(view);
        phaseTwo = view.getBoolean("PhaseTwo", false);
        flightCooldown = view.getInt("FlightCooldown", 200);
        flightTicks = Math.max(0, Math.min(100, view.getInt("FlightTicks", 0)));
        crashing = view.getBoolean("Crashing", false);
        attackCooldown = view.getInt("AttackCooldown", 100);
        for (int i = 0; i < abilityCooldowns.length; i++) abilityCooldowns[i] = view.getInt("AbilityCooldown" + i, 0);
        getDataTracker().set(FLYING, flightTicks > 0);
        setNoGravity(flightTicks > 0);
        applyPhaseSpeed();
        if (phaseTwo) bar.setName(Text.literal("Gabriel – Wrath of Heaven"));
    }
    @Override protected void writeCustomData(WriteView view) {
        super.writeCustomData(view);
        view.putBoolean("PhaseTwo", phaseTwo);
        view.putInt("FlightCooldown", flightCooldown);
        view.putInt("FlightTicks", flightTicks);
        view.putBoolean("Crashing", crashing);
        view.putInt("AttackCooldown", attackCooldown);
        for (int i = 0; i < abilityCooldowns.length; i++) view.putInt("AbilityCooldown" + i, abilityCooldowns[i]);
    }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<GabrielEntity>("movement", 5, state -> state.setAndContinue(RawAnimation.begin().thenLoop(
                state.animatable() instanceof GabrielEntity gabriel && gabriel.isFlying() ? "animation.gabriel.fly" : state.isMoving() ? "animation.gabriel.walk" : "animation.gabriel.idle")))
            .triggerableAnim("attack", RawAnimation.begin().thenPlay("animation.gabriel.attack"))
            .triggerableAnim("spear", RawAnimation.begin().thenPlay("animation.gabriel.spear"))
            .triggerableAnim("judgment", RawAnimation.begin().thenPlay("animation.gabriel.judgment"))
            .triggerableAnim("barrage", RawAnimation.begin().thenPlay("animation.gabriel.barrage"))
            .triggerableAnim("execution", RawAnimation.begin().thenPlay("animation.gabriel.execution"))
            .triggerableAnim("crossfire", RawAnimation.begin().thenPlay("animation.gabriel.crossfire"))
            .triggerableAnim("dive", RawAnimation.begin().thenPlay("animation.gabriel.dive"))
            .triggerableAnim("death", RawAnimation.begin().thenPlay("animation.gabriel.death")));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}