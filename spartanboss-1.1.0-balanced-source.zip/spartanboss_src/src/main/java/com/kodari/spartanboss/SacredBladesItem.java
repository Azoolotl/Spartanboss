package com.kodari.spartanboss;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoItem;
import software.bernie.geckolib.animatable.client.GeoRenderProvider;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * Shared item implementation for the existing Leviathan Axe, Blades of Chaos,
 * and Gabriel weapon. Each item exposes exactly two selectable active abilities.
 */
public class SacredBladesItem extends Item implements GeoItem {
    public static BiConsumer<SacredBladesItem, Consumer<GeoRenderProvider>> rendererFactory =
        (item, consumer) -> consumer.accept(GeoRenderProvider.DEFAULT);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public SacredBladesItem(Settings settings) {
        super(settings);
    }

    @Override
    public void createGeoRenderer(Consumer<GeoRenderProvider> consumer) {
        rendererFactory.accept(this, consumer);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>("static", 0, state -> PlayState.STOP));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    @Override
    public ActionResult use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        int weapon = getWeaponType();
        String[] names = getAbilityNames();
        int selected = stack.getOrDefault(DataComponentTypes.CUSTOM_DATA, NbtComponent.DEFAULT)
            .copyNbt().getInt("AbilityMode", 0);
        selected = Math.floorMod(selected, 2);

        // Sneak + use selects one of the weapon's two abilities; it does not trigger a third ability.
        if (user.isSneaking()) {
            if (world instanceof ServerWorld) {
                int next = 1 - selected;
                NbtComponent.set(DataComponentTypes.CUSTOM_DATA, stack,
                    nbt -> nbt.putInt("AbilityMode", next));
                user.sendMessage(Text.literal("Selected: " + names[next]), true);
            }
            return ActionResult.SUCCESS;
        }

        if (!(world instanceof ServerWorld server)) return ActionResult.SUCCESS;

        long readyAt = WeaponAbilityManager.getAbilityReadyAt(server, user, weapon, selected);
        long now = server.getServer().getOverworld().getTime();
        if (now < readyAt) {
            long remainingSeconds = Math.max(1L, (readyAt - now + 19L) / 20L);
            user.sendMessage(Text.literal(names[selected] + " ready in " + remainingSeconds + "s"), true);
            return ActionResult.SUCCESS;
        }

        if (!WeaponAbilityManager.activate(server, user, stack, weapon, selected)) {
            user.sendMessage(Text.literal(names[selected] + " cannot be activated right now"), true);
            return ActionResult.SUCCESS;
        }

        int cooldownTicks = getCooldownTicks(weapon, selected);
        WeaponAbilityManager.setAbilityCooldown(server, user, weapon, selected, cooldownTicks);

        stack.damage(1, user, hand == Hand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
        user.swingHand(hand, true);
        return ActionResult.SUCCESS;
    }

    private int getWeaponType() {
        if (this == SpartanBoss.FROST_AXE) return 0;
        if (this == SpartanBoss.CHAOS_BLADES) return 1;
        return 2;
    }

    private String[] getAbilityNames() {
        if (this == SpartanBoss.FROST_AXE) return new String[]{"Frost Dominion", "Glacial Spikes"};
        if (this == SpartanBoss.CHAOS_BLADES) return new String[]{"Chaotic Chain Slash", "Spartan Fury"};
        return new String[]{"Divine Dash", "Divine Descent"};
    }

    private int getCooldownTicks(int weapon, int ability) {
        return switch (weapon) {
            case 0 -> ability == 0 ? 40 * 20 : 50 * 20;
            case 1 -> ability == 0 ? 40 * 20 : 50 * 20;
            case 2 -> ability == 0 ? 20 * 20 : 50 * 20;
            default -> 20 * 20;
        };
    }
}
