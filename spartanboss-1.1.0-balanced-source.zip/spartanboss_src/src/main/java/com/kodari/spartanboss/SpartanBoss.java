package com.kodari.spartanboss;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SpawnEggItem;
import net.minecraft.item.ToolMaterial;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.SoundEvent;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.ActionResult;

public class SpartanBoss implements ModInitializer {
    public static final String ID = "spartanboss";
    private static final Identifier BOSS_ID = Identifier.of(ID, "spartan");
    private static final RegistryKey<EntityType<?>> BOSS_KEY = RegistryKey.of(RegistryKeys.ENTITY_TYPE, BOSS_ID);
    public static final EntityType<SpartanEntity> BOSS = Registry.register(Registries.ENTITY_TYPE, BOSS_KEY,
        EntityType.Builder.create(SpartanEntity::new, SpawnGroup.MONSTER).dimensions(0.8f, 2.2f).maxTrackingRange(12).build(BOSS_KEY));
    private static final Identifier EGG_ID = Identifier.of(ID, "spartan_spawn_egg");
    private static final RegistryKey<Item> EGG_KEY = RegistryKey.of(RegistryKeys.ITEM, EGG_ID);
    public static final Item EGG = Registry.register(Registries.ITEM, EGG_KEY,
        new SpawnEggItem(new Item.Settings().registryKey(EGG_KEY).spawnEgg(BOSS)));
    private static final RegistryKey<EntityType<?>> GABRIEL_KEY = RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(ID, "gabriel"));
    public static final EntityType<GabrielEntity> GABRIEL = Registry.register(Registries.ENTITY_TYPE, GABRIEL_KEY,
        EntityType.Builder.create(GabrielEntity::new, SpawnGroup.MONSTER).dimensions(1.0f, 2.8f).maxTrackingRange(16).build(GABRIEL_KEY));
    private static final RegistryKey<Item> GABRIEL_EGG_KEY = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, "gabriel_spawn_egg"));
    public static final Item GABRIEL_EGG = Registry.register(Registries.ITEM, GABRIEL_EGG_KEY,
        new SpawnEggItem(new Item.Settings().registryKey(GABRIEL_EGG_KEY).spawnEgg(GABRIEL)));
    private static final RegistryKey<Item> BLADES_KEY = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, "sacred_dual_blades"));
    public static final Item BLADES = Registry.register(Registries.ITEM, BLADES_KEY,
        new SacredBladesItem(new Item.Settings().registryKey(BLADES_KEY).sword(ToolMaterial.NETHERITE, 3.0f, -1.8f)));
    private static final RegistryKey<Item> FROST_AXE_KEY = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, "frost_axe"));
    public static final Item FROST_AXE = Registry.register(Registries.ITEM, FROST_AXE_KEY,
        new SacredBladesItem(new Item.Settings().registryKey(FROST_AXE_KEY).sword(ToolMaterial.DIAMOND, 3.0f, -2.8f)));
    private static final RegistryKey<Item> CHAOS_BLADES_KEY = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ID, "chaos_blades"));
    public static final Item CHAOS_BLADES = Registry.register(Registries.ITEM, CHAOS_BLADES_KEY,
        new SacredBladesItem(new Item.Settings().registryKey(CHAOS_BLADES_KEY).sword(ToolMaterial.DIAMOND, 3.0f, -2.0f)));
    private static final RegistryKey<EntityType<?>> PROJECTILE_KEY = RegistryKey.of(RegistryKeys.ENTITY_TYPE, Identifier.of(ID, "combat_projectile"));
    public static final EntityType<CombatProjectileEntity> PROJECTILE = Registry.register(Registries.ENTITY_TYPE, PROJECTILE_KEY,
        EntityType.Builder.create(CombatProjectileEntity::new, SpawnGroup.MISC).dimensions(0.35f, 0.35f)
            .maxTrackingRange(12).trackingTickInterval(1).disableSaving().disableSummon().build(PROJECTILE_KEY));
    private static final RegistryKey<Block> ICE_KEY = RegistryKey.of(RegistryKeys.BLOCK, Identifier.of(ID, "temporary_ice"));
    public static final Block TEMPORARY_ICE = Registry.register(Registries.BLOCK, ICE_KEY,
        new TemporaryHazardBlock(AbstractBlock.Settings.create().registryKey(ICE_KEY).strength(0.5f).dropsNothing(), false));
    private static final RegistryKey<Block> FIRE_KEY = RegistryKey.of(RegistryKeys.BLOCK, Identifier.of(ID, "temporary_fire"));
    public static final Block TEMPORARY_FIRE = Registry.register(Registries.BLOCK, FIRE_KEY,
        new TemporaryHazardBlock(AbstractBlock.Settings.create().registryKey(FIRE_KEY).noCollision().replaceable().luminance(state -> 12).dropsNothing(), true));
    private static final RegistryKey<Block> GLACIAL_SPIKE_KEY = RegistryKey.of(RegistryKeys.BLOCK, Identifier.of(ID, "glacial_spike"));
    public static final Block GLACIAL_SPIKE = Registry.register(Registries.BLOCK, GLACIAL_SPIKE_KEY,
        new TemporaryHazardBlock(AbstractBlock.Settings.create().registryKey(GLACIAL_SPIKE_KEY).strength(0.5f).dropsNothing(), false, true));
    public static final SoundEvent FROST_SOUND = registerSound("kratos.frost");
    public static final SoundEvent CHAIN_SOUND = registerSound("kratos.chain");
    public static final SoundEvent RAGE_SOUND = registerSound("kratos.rage");
    public static final SoundEvent SLAM_SOUND = registerSound("kratos.slam");
    public static final SoundEvent DIVINE_SOUND = registerSound("gabriel.divine");
    public static final SoundEvent CRASH_SOUND = registerSound("gabriel.crash");

    private static SoundEvent registerSound(String name) {
        Identifier id = Identifier.of(ID, name);
        return Registry.register(Registries.SOUND_EVENT, id, SoundEvent.of(id));
    }

    @Override
    public void onInitialize() {
        FabricDefaultAttributeRegistry.register(BOSS, SpartanEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(GABRIEL, GabrielEntity.createAttributes());
        ServerTickEvents.END_SERVER_TICK.register(WeaponAbilityManager::tickServer);
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> WeaponAbilityManager.cancelPlayer(handler.player));
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) ->
            WeaponAbilityManager.isStunned(player) ? ActionResult.FAIL : ActionResult.PASS);
        Registry.register(Registries.ITEM_GROUP, Identifier.of(ID, "items"), FabricItemGroup.builder()
            .displayName(Text.translatable("itemGroup.spartanboss.items"))
            .icon(() -> new ItemStack(EGG)).entries((context, entries) -> { entries.add(EGG); entries.add(GABRIEL_EGG); entries.add(BLADES); entries.add(FROST_AXE); entries.add(CHAOS_BLADES); }).build());
    }
}