package com.kodari.spartanboss;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.minecraft.block.Blocks;
import net.minecraft.entity.DamageUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.storage.ReadView;
import net.minecraft.storage.WriteView;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animatable.manager.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

public class SpartanEntity extends HostileEntity implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private final ServerBossBar bar = new ServerBossBar(Text.literal("KRATOS – THE GHOST OF SPARTA"), BossBar.Color.RED, BossBar.Style.PROGRESS);
    private final int[] abilityCooldowns = new int[14];
    private final Set<UUID> waveHits = new HashSet<>();
    private boolean phaseTwo;
    private int rageTicks;
    private int rageCooldown;
    private int rageWarningTicks;
    private int attackCooldown = 100;
    private int defenseCooldown;
    private int axeHiddenTicks;
    private int lastParticipantCount = -1;
    private int targetSwitchCooldown;
    private int sequence = -1;
    private int sequenceAge;
    private int sequenceDuration;
    private LivingEntity sequenceTarget;

    public SpartanEntity(EntityType<? extends SpartanEntity> type, World world) {
        super(type, world);
        setPersistent();
        setEquipmentDropChance(EquipmentSlot.MAINHAND, 0);
        setEquipmentDropChance(EquipmentSlot.OFFHAND, 0);
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes().add(EntityAttributes.MAX_HEALTH, 1000)
            .add(EntityAttributes.ATTACK_DAMAGE, 10.5).add(EntityAttributes.ARMOR, 13)
            .add(EntityAttributes.MOVEMENT_SPEED, 0.29).add(EntityAttributes.FOLLOW_RANGE, 40)
            .add(EntityAttributes.KNOCKBACK_RESISTANCE, 0.8).add(EntityAttributes.EXPLOSION_KNOCKBACK_RESISTANCE, 0.8);
    }

    @Override protected void initGoals() {
        goalSelector.add(1, new MeleeAttackGoal(this, 1.1, false));
        targetSelector.add(1, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    protected void mobTick(ServerWorld world) {
        super.mobTick(world);
        if (WeaponAbilityManager.isStunned(this)) {
            bar.setPercent(getHealth() / getMaxHealth());
            return;
        }
        if (age % 20 == 0 || lastParticipantCount < 0) {
            int participants = BossBalance.countParticipants(this, world);
            if (participants != lastParticipantCount) {
                BossBalance.updateBossAttributes(this, participants, 10.5);
                lastParticipantCount = participants;
            }
        }
        if (targetSwitchCooldown > 0) targetSwitchCooldown--;
        if (targetSwitchCooldown <= 0) {
            PlayerEntity chaoticTarget = BossBalance.chooseChaoticTarget(this, world, 40.0);
            setTarget(chaoticTarget);
            targetSwitchCooldown = 40 + getRandom().nextInt(61);
        }
        if (!phaseTwo && getHealth() <= getMaxHealth() * 0.5f) {
            phaseTwo = true;
            bar.setName(Text.literal("KRATOS – THE GOD OF WAR"));
            particles(world, ParticleTypes.FLAME, 100, 2);
            playSound(SpartanBoss.RAGE_SOUND, 2, 0.8f);
        }
        if (age % 20 == 0 && getHealth() < getMaxHealth()) heal(0.5f);
        bar.setPercent(getHealth() / getMaxHealth());
        if (age % 10 == 0) {
            breakCobwebs(world);
            updateEquipment();
        }
        if (axeHiddenTicks > 0) axeHiddenTicks--;
        if (defenseCooldown > 0) defenseCooldown--;
        if (rageCooldown > 0) rageCooldown--;
        if (attackCooldown > 0) attackCooldown--;
        for (int i = 0; i < abilityCooldowns.length; i++) if (abilityCooldowns[i] > 0) abilityCooldowns[i]--;

        if (rageTicks > 0) {
            rageTicks--;
            if (age % 5 == 0) particles(world, new DustParticleEffect(0xD50000, 1.8f), 25, 0.7);
            if (rageTicks == 0) setKnockbackResistance(0.8);
        } else {
            boolean rageReady = getTarget() != null && getHealth() <= getMaxHealth() * 0.50f && rageCooldown == 0;
            if (rageWarningTicks > 0) {
                rageWarningTicks--;
                if (rageWarningTicks % 5 == 0) particles(world, new DustParticleEffect(0xFF5A20, 1.25f), 22, 0.9);
                if (rageWarningTicks == 0 && rageReady) activateSpartanRage(world);
            } else if (rageReady) {
                // A one-second telegraph gives the party a chance to spread out before Rage.
                rageWarningTicks = 20;
                playSound(SpartanBoss.RAGE_SOUND, 1.8f, 1.25f);
                particles(world, new DustParticleEffect(0xFF8A30, 1.5f), 55, 1.0);
            }
        }
        if (sequence >= 0) {
            tickSequence(world);
            return;
        }
        LivingEntity target = getTarget();
        if (target == null || !target.isAlive() || attackCooldown > 0) return;
        List<Integer> available = new ArrayList<>();
        int first = rageTicks > 0 ? 11 : 0;
        int last = rageTicks > 0 ? 13 : phaseTwo ? 10 : 5;
        for (int i = first; i <= last; i++) {
            if (abilityCooldowns[i] == 0 && (i != 0 || axeHiddenTicks == 0)) available.add(i);
        }
        if (available.isEmpty()) {
            attackCooldown = 30;
            return;
        }
        int choice = available.get(getRandom().nextInt(available.size()));
        abilityCooldowns[choice] = rageTicks > 0 ? 400 : phaseTwo ? 420 : 600;
        attackCooldown = rageTicks > 0 ? 45 : phaseTwo ? 90 : 120;
        triggerAnim("movement", rageTicks > 0 ? "rage" : "attack");
        useAbility(world, target, choice);
    }

    private void useAbility(ServerWorld world, LivingEntity target, int choice) {
        switch (choice) {
            case 0 -> {
                if (CombatProjectileEntity.launch(world, this, new ItemStack(SpartanBoss.FROST_AXE), CombatProjectileEntity.AXE,
                        target.getEyePos().subtract(getEyePos()), phaseTwo ? 16.5f : 15.0f)) {
                    axeHiddenTicks = 100;
                    updateEquipment();
                }
                playSound(SpartanBoss.FROST_SOUND, 2, 0.8f);
            }
            case 1 -> startSequence(1, 20, target);
            case 2 -> cone(world, target, 4.5, 20, true, false, 0.5);
            case 3 -> {
                area(world, 10, 18, true, false, 1.2);
                ArenaEffects.explosion(world, this, 3.0f);
                ArenaEffects.frostSpikes(world, this, 10);
                playSound(SpartanBoss.SLAM_SOUND, 2, 0.7f);
            }
            case 4 -> {
                launchToward(target, 1.0, 0.8);
                startSequence(4, 60, target);
            }
            case 5 -> {
                startSequence(5, 24, target);
                playSound(SpartanBoss.RAGE_SOUND, 1.5f, 1.2f);
            }
            case 6 -> {
                startSequence(6, 16, target);
                playSound(SpartanBoss.CHAIN_SOUND, 2, 0.9f);
            }
            case 7 -> startSequence(7, 60, target);
            case 8 -> startSequence(8, 36, target);
            case 9 -> startSequence(9, 60, target);
            case 10 -> {
                launchToward(target, 1.4, 0.2);
                startSequence(10, 50, target);
            }
            case 11 -> startSequence(11, 48, target);
            case 12 -> {
                setVelocity(0, 1.0, 0);
                velocityDirty = true;
                startSequence(12, 60, target);
            }
            case 13 -> {
                area(world, 10, 20, false, false, 1.2, BossBalance.AttackTier.ULTIMATE);
                particles(world, new DustParticleEffect(0xFF1200, 2.0f), 120, 3);
                ArenaEffects.explosion(world, this, 3.5f);
                playSound(SpartanBoss.RAGE_SOUND, 2, 0.7f);
            }
            default -> throw new IllegalArgumentException("Unknown combat ability");
        }
    }

    private void startSequence(int ability, int duration, LivingEntity target) {
        sequence = ability;
        sequenceAge = 0;
        sequenceDuration = duration;
        sequenceTarget = target;
        waveHits.clear();
    }

    private void tickSequence(ServerWorld world) {
        sequenceAge++;
        LivingEntity target = sequenceTarget;
        if (sequence == 1) {
            double radius = sequenceAge * 0.6;
            ArenaEffects.ring(world, this, ParticleTypes.SNOWFLAKE, radius, 48);
            damageWave(world, radius, 15, true, false);
            if (sequenceAge == 20) ArenaEffects.frostSpikes(world, this, 12);
        } else if (sequence == 4 || sequence == 12) {
            if (sequenceAge > 8 && isOnGround()) {
                boolean rageSlam = sequence == 12;
                area(world, rageSlam ? 15 : 4, rageSlam ? 25 : 15, false, false,
                    rageSlam ? 1.5 : 1.0, rageSlam ? BossBalance.AttackTier.ULTIMATE : BossBalance.AttackTier.HEAVY);
                ArenaEffects.explosion(world, this, rageSlam ? 4.0f : 2.5f);
                particles(world, rageSlam ? new DustParticleEffect(0xCE1300, 2.0f) : ParticleTypes.CRIT, 80, 2);
                sequenceAge = sequenceDuration;
            }
        } else if (sequence == 5) {
            particles(world, new DustParticleEffect(0xFF2020, 1.3f), 8, 0.6);
            if (sequenceAge == 24 && target != null && target.isAlive()) {
                cone(world, target, 5, 25, false, false, 1.2);
                ArenaEffects.explosion(world, this, 2.0f);
            }
        } else if (sequence == 6 && target != null && target.isAlive()) {
            chain(world, target, sequenceAge <= 8 ? sequenceAge / 8.0 : (16 - sequenceAge) / 8.0);
            if (sequenceAge == 8 && distanceTo(target) <= 15) {
                BossBalance.applyBossDamage(world, this, target, getDamageSources().mobAttack(this),
                    phaseTwo ? 16.5f : 15, BossBalance.AttackTier.HEAVY);
                target.setOnFireFor(3);
                push(target, -1.0);
            }
        } else if (sequence == 7) {
            ArenaEffects.ring(world, this, ParticleTypes.FLAME, 12, 64);
            if (sequenceAge % 10 == 0) area(world, 12, 3, false, true, 0.1);
        } else if (sequence == 8 && target != null && target.isAlive()) {
            chain(world, target, Math.min(1, (sequenceAge % 12) / 6.0));
            if (sequenceAge % 12 == 0) {
                cone(world, target, 7, 8, false, true, 0.6);
                if (sequenceAge == 36) ArenaEffects.explosionAt(world, this, target.getX(), target.getY(), target.getZ(), 1.8f);
            }
        } else if (sequence == 9) {
            int waveAge = (sequenceAge - 1) % 20 + 1;
            if (waveAge == 1) waveHits.clear();
            double radius = waveAge * 0.75;
            ArenaEffects.ring(world, this, ParticleTypes.FLAME, radius, 64);
            damageWave(world, radius, 20, false, true);
            if (waveAge == 20) ArenaEffects.firePatches(world, this, 15);
            if (sequenceAge == 60) ArenaEffects.explosion(world, this, 2.5f);
        } else if (sequence == 10) {
            if (target != null && target.isAlive() && sequenceAge % 10 == 1) launchToward(target, 1.05, 0.12);
            if (sequenceAge % 10 == 0) {
                area(world, 4, 5, false, true, sequenceAge == 50 ? 1.0 : 0.15);
                if (sequenceAge == 50) ArenaEffects.explosion(world, this, 2.5f);
            }
        } else if (sequence == 11 && sequenceAge % 12 == 0) {
            area(world, 3.5, 6, false, false, sequenceAge == 48 ? 1.2 : 0.1);
            triggerAnim("movement", "rage");
        }
        if (sequenceAge >= sequenceDuration) {
            sequence = -1;
            sequenceTarget = null;
            waveHits.clear();
        }
    }

    private void damageWave(ServerWorld world, double radius, float damage, boolean frost, boolean fire) {
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(radius + 1),
                p -> p.isAlive() && !p.isCreative() && !p.isSpectator() && !waveHits.contains(p.getUuid()))) {
            double dx = player.getX() - getX(), dz = player.getZ() - getZ();
            double distance = Math.sqrt(dx * dx + dz * dz);
            if (Math.abs(player.getY() - getY()) > 2.0 || (fire && !player.isOnGround()) || Math.abs(distance - radius) > 1.2) continue;
            waveHits.add(player.getUuid());
            BossBalance.applyBossDamage(world, this, player, getDamageSources().mobAttack(this),
                damage * (phaseTwo ? 1.1f : 1), BossBalance.AttackTier.HEAVY);
            if (frost) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
            if (fire) player.setOnFireFor(4);
        }
    }

    private void chain(ServerWorld world, LivingEntity target, double extension) {
        Vec3d start = getEyePos();
        Vec3d direction = target.getEyePos().subtract(start);
        double length = Math.min(15, direction.length()) * Math.max(0, extension);
        direction = direction.normalize();
        for (int i = 0; i <= 24; i++) {
            Vec3d point = start.add(direction.multiply(length * i / 24.0));
            world.spawnParticles(i % 3 == 0 ? ParticleTypes.FLAME : ParticleTypes.CRIT, point.x, point.y, point.z, 1, 0.03, 0.03, 0.03, 0);
        }
    }

    private void cone(ServerWorld world, LivingEntity target, double radius, float damage, boolean frost, boolean fire, double knockback) {
        cone(world, target, radius, damage, frost, fire, knockback, BossBalance.AttackTier.HEAVY);
    }

    private void cone(ServerWorld world, LivingEntity target, double radius, float damage, boolean frost, boolean fire,
                      double knockback, BossBalance.AttackTier tier) {
        Vec3d facing = new Vec3d(target.getX() - getX(), 0, target.getZ() - getZ()).normalize();
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(radius), p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            Vec3d offset = new Vec3d(player.getX() - getX(), 0, player.getZ() - getZ());
            if (offset.length() > radius || Math.abs(player.getY() - getY()) > 3 || offset.normalize().dotProduct(facing) < -0.1) continue;
            BossBalance.applyBossDamage(world, this, player, getDamageSources().mobAttack(this),
                damage * (phaseTwo ? 1.1f : 1), tier);
            if (frost) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
            if (fire) player.setOnFireFor(3);
            push(player, knockback);
        }
        particles(world, frost ? ParticleTypes.SNOWFLAKE : fire ? ParticleTypes.FLAME : ParticleTypes.SWEEP_ATTACK, 40, 1.5);
        playSound(frost ? SpartanBoss.FROST_SOUND : fire ? SpartanBoss.CHAIN_SOUND : SpartanBoss.SLAM_SOUND, 1.5f, 1);
    }

    private void area(ServerWorld world, double radius, float damage, boolean frost, boolean fire, double knockback) {
        area(world, radius, damage, frost, fire, knockback, BossBalance.AttackTier.HEAVY);
    }

    private void area(ServerWorld world, double radius, float damage, boolean frost, boolean fire, double knockback,
                      BossBalance.AttackTier tier) {
        ParticleEffect effect = frost ? ParticleTypes.SNOWFLAKE : fire ? ParticleTypes.FLAME : ParticleTypes.CRIT;
        ArenaEffects.ring(world, this, effect, radius, 48);
        for (PlayerEntity player : world.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(radius), p -> p.isAlive() && !p.isCreative() && !p.isSpectator())) {
            if (squaredDistanceTo(player) > radius * radius) continue;
            BossBalance.applyBossDamage(world, this, player, getDamageSources().mobAttack(this),
                damage * (phaseTwo ? 1.1f : 1), tier);
            if (frost) player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
            if (fire) player.setOnFireFor(3);
            if (knockback != 0) push(player, knockback);
        }
        playSound(frost ? SpartanBoss.FROST_SOUND : fire ? SpartanBoss.CHAIN_SOUND : SpartanBoss.SLAM_SOUND, 1.5f, 0.8f);
    }

    private void launchToward(LivingEntity target, double speed, double up) {
        Vec3d direction = new Vec3d(target.getX() - getX(), 0, target.getZ() - getZ()).normalize();
        setVelocity(direction.x * speed, up, direction.z * speed);
        velocityDirty = true;
    }

    private void push(LivingEntity target, double strength) {
        Vec3d direction = new Vec3d(target.getX() - getX(), 0, target.getZ() - getZ()).normalize();
        target.setVelocity(direction.x * strength, 0.4, direction.z * strength);
        target.velocityDirty = true;
    }

    private void particles(ServerWorld world, ParticleEffect effect, int count, double spread) {
        world.spawnParticles(effect, getX(), getY() + 1, getZ(), count, spread, spread, spread, 0.03);
    }

    private void breakCobwebs(ServerWorld world) {
        for (BlockPos pos : BlockPos.iterateOutwards(getBlockPos(), 1, 2, 1)) {
            if (world.getBlockState(pos).isOf(Blocks.COBWEB) && getBoundingBox().intersects(pos.getX(), pos.getY(), pos.getZ(), pos.getX() + 1, pos.getY() + 1, pos.getZ() + 1)) world.breakBlock(pos, true, this, 512);
        }
    }

    private void updateEquipment() {
        Item main = rageTicks > 0 ? null : phaseTwo ? SpartanBoss.CHAOS_BLADES : axeHiddenTicks > 0 ? null : SpartanBoss.FROST_AXE;
        Item off = rageTicks == 0 && phaseTwo && axeHiddenTicks == 0 ? SpartanBoss.FROST_AXE : null;
        setHeldItem(EquipmentSlot.MAINHAND, main);
        setHeldItem(EquipmentSlot.OFFHAND, off);
    }

    private void activateSpartanRage(ServerWorld world) {
        rageTicks = 200;
        rageCooldown = phaseTwo ? 1300 : 1500;
        addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200, 0, false, false));
        addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 0, false, false));
        addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 200, 0, false, false));
        setKnockbackResistance(0.90);
        playSound(SpartanBoss.RAGE_SOUND, 2.5f, 0.7f);
        particles(world, new DustParticleEffect(0xFF1800, 2.0f), 100, 1.3);
        triggerAnim("movement", "rage");
        updateEquipment();
    }

    private void setHeldItem(EquipmentSlot slot, Item item) {
        ItemStack current = getEquippedStack(slot);
        if (item == null ? !current.isEmpty() : !current.isOf(item)) equipStack(slot, item == null ? ItemStack.EMPTY : new ItemStack(item));
    }

    private void setKnockbackResistance(double value) {
        EntityAttributeInstance attribute = getAttributeInstance(EntityAttributes.KNOCKBACK_RESISTANCE);
        if (attribute != null) attribute.setBaseValue(value);
        EntityAttributeInstance explosionAttribute = getAttributeInstance(EntityAttributes.EXPLOSION_KNOCKBACK_RESISTANCE);
        if (explosionAttribute != null) explosionAttribute.setBaseValue(value);
    }

    public void onAxeReturned() { axeHiddenTicks = 0; updateEquipment(); }
    public boolean isRaging() { return hasStatusEffect(StatusEffects.STRENGTH); }

    @Override protected float modifyAppliedDamage(DamageSource source, float amount) {
        float reduced = super.modifyAppliedDamage(source, amount);
        return source.isIn(DamageTypeTags.BYPASSES_EFFECTS) || source.isIn(DamageTypeTags.BYPASSES_ENCHANTMENTS)
            ? reduced : DamageUtil.getInflictedDamage(reduced, 13);
    }

    @Override public boolean handleFallDamage(double distance, float multiplier, DamageSource source) { return false; }
    @Override public boolean tryAttack(ServerWorld world, Entity target) {
        triggerAnim("movement", rageTicks > 0 ? "rage" : "attack");
        return super.tryAttack(world, target);
    }

    @Override public boolean damage(ServerWorld world, DamageSource source, float amount) {
        Entity attacker = source.getAttacker();
        if (defenseCooldown == 0 && attacker != null && getRandom().nextInt(8) == 0) {
            defenseCooldown = 200;
            playSound(SpartanBoss.CHAIN_SOUND, 1, 1.5f);
            if (source.getSource() == attacker && attacker instanceof LivingEntity living && distanceTo(living) < 4) {
                BossBalance.applyBossDamage(world, this, living, getDamageSources().mobAttack(this),
                    8.0f, BossBalance.AttackTier.NORMAL);
                push(living, 0.8);
            } else if (source.getSource() != attacker) {
                Vec3d away = new Vec3d(getZ() - attacker.getZ(), 0, attacker.getX() - getX()).normalize();
                setVelocity(away.multiply(0.7).add(0, getVelocity().y, 0));
                velocityDirty = true;
            }
            return false;
        }
        return super.damage(world, source, amount);
    }

    @Override public void onDeath(DamageSource source) {
        if (!getEntityWorld().isClient()) {
            dropItem(new ItemStack(SpartanBoss.FROST_AXE), true, false);
            dropItem(new ItemStack(SpartanBoss.CHAOS_BLADES), true, false);
        }
        super.onDeath(source);
    }

    @Override public void onStartedTrackingBy(ServerPlayerEntity player) { super.onStartedTrackingBy(player); bar.addPlayer(player); }
    @Override public void onStoppedTrackingBy(ServerPlayerEntity player) { super.onStoppedTrackingBy(player); bar.removePlayer(player); }
    @Override protected void readCustomData(ReadView view) {
        super.readCustomData(view);
        phaseTwo = view.getBoolean("PhaseTwo", false);
        rageCooldown = view.getInt("RageCooldown", 0);
        rageWarningTicks = view.getInt("RageWarningTicks", 0);
        rageTicks = view.getInt("RageTicks", 0);
        attackCooldown = view.getInt("AttackCooldown", 100);
        defenseCooldown = view.getInt("DefenseCooldown", 0);
        for (int i = 0; i < abilityCooldowns.length; i++) abilityCooldowns[i] = view.getInt("AbilityCooldown" + i, 0);
        if (phaseTwo) bar.setName(Text.literal("KRATOS – THE GOD OF WAR"));
        setKnockbackResistance(rageTicks > 0 ? 0.90 : 0.80);
    }
    @Override protected void writeCustomData(WriteView view) {
        super.writeCustomData(view);
        view.putBoolean("PhaseTwo", phaseTwo);
        view.putInt("RageCooldown", rageCooldown);
        view.putInt("RageWarningTicks", rageWarningTicks);
        view.putInt("RageTicks", rageTicks);
        view.putInt("AttackCooldown", attackCooldown);
        view.putInt("DefenseCooldown", defenseCooldown);
        for (int i = 0; i < abilityCooldowns.length; i++) view.putInt("AbilityCooldown" + i, abilityCooldowns[i]);
    }
    @Override public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>("movement", 5, state -> state.setAndContinue(RawAnimation.begin().thenLoop(state.isMoving() ? "animation.spartan.walk" : "animation.spartan.idle")))
            .triggerableAnim("attack", RawAnimation.begin().thenPlay("animation.spartan.attack"))
            .triggerableAnim("rage", RawAnimation.begin().thenPlay("animation.spartan.rage")));
    }
    @Override public AnimatableInstanceCache getAnimatableInstanceCache() { return cache; }
}