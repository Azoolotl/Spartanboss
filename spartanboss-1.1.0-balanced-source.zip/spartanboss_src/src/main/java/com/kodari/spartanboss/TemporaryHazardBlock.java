package com.kodari.spartanboss;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.EntityCollisionHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.block.ShapeContext;

public class TemporaryHazardBlock extends Block {
    private static final VoxelShape SPIKE_SHAPE = VoxelShapes.union(
        VoxelShapes.cuboid(0.25, 0.0, 0.25, 0.75, 0.56, 0.75),
        VoxelShapes.cuboid(0.375, 0.56, 0.375, 0.625, 1.0, 0.625)
    );

    private final boolean burning;
    private final boolean spiky;

    public TemporaryHazardBlock(Settings settings, boolean burning) {
        this(settings, burning, false);
    }

    public TemporaryHazardBlock(Settings settings, boolean burning, boolean spiky) {
        super(settings);
        this.burning = burning;
        this.spiky = spiky;
    }

    @Override
    protected VoxelShape getOutlineShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return spiky ? SPIKE_SHAPE : super.getOutlineShape(state, world, pos, context);
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockView world, BlockPos pos, ShapeContext context) {
        return spiky ? SPIKE_SHAPE : super.getCollisionShape(state, world, pos, context);
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState oldState, boolean notify) {
        super.onBlockAdded(state, world, pos, oldState, notify);
        if (!world.isClient() && !oldState.isOf(this)) {
            world.scheduleBlockTick(pos, this, burning ? 80 : 120);
        }
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        if (world.getBlockState(pos).isOf(this)) world.removeBlock(pos, false);
    }

    @Override
    public void onSteppedOn(World world, BlockPos pos, BlockState state, Entity entity) {
        if (!world.isClient() && spiky && entity instanceof LivingEntity living && living.isAlive()) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1, false, false));
            if (world instanceof ServerWorld server) {
                server.spawnParticles(ParticleTypes.SNOWFLAKE, entity.getX(), entity.getY() + 0.15, entity.getZ(),
                    4, 0.15, 0.08, 0.15, 0.01);
                server.spawnParticles(new DustParticleEffect(0x79DFFF, 0.8f),
                    entity.getX(), entity.getY() + 0.15, entity.getZ(), 2, 0.1, 0.05, 0.1, 0.01);
            }
        }
        super.onSteppedOn(world, pos, state, entity);
    }

    @Override
    protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity,
                                     EntityCollisionHandler handler, boolean moved) {
        if (world.isClient()) return;

        if (burning) {
            entity.setOnFireFor(2);
        } else if (spiky && entity instanceof LivingEntity living && living.isAlive()) {
            living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1, false, false));
            if (world instanceof ServerWorld server && moved) {
                server.spawnParticles(ParticleTypes.SNOWFLAKE, entity.getX(), entity.getY() + 0.3, entity.getZ(),
                    5, 0.18, 0.18, 0.18, 0.01);
                server.spawnParticles(new DustParticleEffect(0x79DFFF, 0.9f),
                    entity.getX(), entity.getY() + 0.3, entity.getZ(), 3, 0.12, 0.12, 0.12, 0.01);
            }
        }
    }
}
