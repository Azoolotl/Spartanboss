package com.kodari.spartanboss;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerAbilities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import net.minecraft.world.RaycastContext;

/**
 * Server-authoritative implementation of the six active legendary weapon abilities.
 * Ability selection is stored on the weapon stack; cooldowns are tracked per player and ability.
 */
public final class WeaponAbilityManager {
    private static final int FROST_DOMINION_TICKS = 100;
    private static final int CHAIN_SLASH_INTERVAL = 4;
    private static final int SPARTAN_FURY_TICKS = 160;
    private static final int DIVINE_DESCENT_FLIGHT_TICKS = 100;
    private static final Map<UUID, SlashState> ACTIVE_SLASHES = new HashMap<>();
    private static final Map<UUID, FlightState> ACTIVE_DESCENTS = new HashMap<>();
    private static final Map<UUID, StunState> ACTIVE_STUNS = new HashMap<>();
    private static final Map<UUID, Integer> ACTIVE_FURY = new HashMap<>();
    private static final Map<UUID, long[]> PLAYER_COOLDOWNS = new HashMap<>();

    private WeaponAbilityManager() {
        throw new AssertionError();
    }

    public static long getAbilityReadyAt(ServerWorld world, PlayerEntity player, int weapon, int ability) {
        long[] cooldowns = PLAYER_COOLDOWNS.get(player.getUuid());
        return cooldowns == null ? 0L : cooldowns[weapon * 2 + ability];
    }

    public static void setAbilityCooldown(ServerWorld world, PlayerEntity player, int weapon, int ability, int cooldownTicks) {
        long[] cooldowns = PLAYER_COOLDOWNS.computeIfAbsent(player.getUuid(), ignored -> new long[6]);
        cooldowns[weapon * 2 + ability] = world.getServer().getOverworld().getTime() + cooldownTicks;
    }

    public static boolean activate(ServerWorld world, PlayerEntity player, ItemStack stack, int weapon, int ability) {
        switch (weapon) {
            case 0 -> {
                if (ability == 0) frostDominion(world, player);
                else glacialSpikes(world, player);
                return true;
            }
            case 1 -> {
                if (ability == 0) return startChainSlash(world, player);
                return spartanFury(world, player);
            }
            case 2 -> {
                if (ability == 0) {
                    divineDash(world, player);
                    return true;
                }
                return player instanceof ServerPlayerEntity serverPlayer && divineDescent(world, serverPlayer);
            }
            default -> throw new IllegalArgumentException("Unknown legendary weapon type: " + weapon);
        }
    }

    private static void frostDominion(ServerWorld world, PlayerEntity player) {
        Vec3d center = player.getEntityPos();
        world.spawnParticles(new DustParticleEffect(0x78DFFF, 2.2f), center.x, center.y + 0.8, center.z,
            120, 1.8, 0.9, 1.8, 0.08);
        world.spawnParticles(ParticleTypes.SNOWFLAKE, center.x, center.y + 0.8, center.z,
            180, 2.5, 1.0, 2.5, 0.05);
        for (int i = 0; i < 80; i++) {
            double angle = Math.PI * 2.0 * i / 80.0;
            double x = center.x + Math.cos(angle) * 10.0;
            double z = center.z + Math.sin(angle) * 10.0;
            world.spawnParticles(new DustParticleEffect(0x78DFFF, 1.4f), x, center.y + 0.15, z, 2, 0.02, 0.05, 0.02, 0);
        }

        Box area = player.getBoundingBox().expand(10.0);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, area,
                entity -> entity != player && entity.isAlive() && !player.isTeammate(entity)
                    && (!(entity instanceof PlayerEntity p) || (!p.isCreative() && !p.isSpectator())))) {
            if (target.squaredDistanceTo(player) > 100.0) continue;
            applyStun(world, target, player);
            world.spawnParticles(ParticleTypes.SNOWFLAKE, target.getX(), target.getY() + 1.0, target.getZ(),
                30, 0.55, 0.8, 0.55, 0.03);
            world.spawnParticles(new DustParticleEffect(0x8BE5FF, 1.5f), target.getX(), target.getY() + 0.8, target.getZ(),
                14, 0.35, 0.55, 0.35, 0.02);
        }
        player.playSound(SpartanBoss.FROST_SOUND, 2.0f, 0.72f);
    }

    private static void applyStun(ServerWorld world, LivingEntity target, Entity source) {
        // Ordinary targets receive the full five-second stun. Bosses retain partial
        // resistance so the ability remains useful without shutting down a boss phase.
        int stunDuration = (target instanceof SpartanEntity || target instanceof GabrielEntity)
            ? FROST_DOMINION_TICKS / 2 : FROST_DOMINION_TICKS;
        StunState existing = ACTIVE_STUNS.get(target.getUuid());
        if (existing != null) {
            existing.ticksRemaining = Math.max(existing.ticksRemaining, stunDuration + 1);
            return;
        }

        StunState state = new StunState(target, world, stunDuration + 1);
        if (target instanceof MobEntity mob) {
            mob.setAiDisabled(true);
        } else if (target instanceof PlayerEntity player) {
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, FROST_DOMINION_TICKS, 10, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, FROST_DOMINION_TICKS, 10, false, false));
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.MINING_FATIGUE, FROST_DOMINION_TICKS, 10, false, false));
        }
        target.setVelocity(Vec3d.ZERO);
        target.velocityDirty = true;
        ACTIVE_STUNS.put(target.getUuid(), state);
    }

    private static StatusEffectInstance copyEffect(StatusEffectInstance effect) {
        return effect == null ? null : new StatusEffectInstance(effect);
    }

    private static void restoreEffect(PlayerEntity player, StatusEffectInstance previous, int elapsedTicks) {
        if (previous == null) return;
        int remaining = previous.getDuration() == -1 ? -1 : Math.max(0, previous.getDuration() - elapsedTicks);
        if (remaining == 0) return;
        player.addStatusEffect(new StatusEffectInstance(previous.getEffectType(), remaining,
            previous.getAmplifier(), previous.isAmbient(), previous.shouldShowParticles(), previous.shouldShowIcon()));
    }

    private static void restoreStun(StunState state) {
        LivingEntity entity = state.entity;
        if (entity instanceof MobEntity mob && mob.isAlive()) {
            mob.setAiDisabled(state.previousAiDisabled);
        }
        if (entity instanceof PlayerEntity player && player.isAlive()) {
            player.removeStatusEffect(StatusEffects.SLOWNESS);
            player.removeStatusEffect(StatusEffects.WEAKNESS);
            player.removeStatusEffect(StatusEffects.MINING_FATIGUE);
            restoreEffect(player, state.previousSlowness, FROST_DOMINION_TICKS);
            restoreEffect(player, state.previousWeakness, FROST_DOMINION_TICKS);
            restoreEffect(player, state.previousMiningFatigue, FROST_DOMINION_TICKS);
        }
    }

    private static void glacialSpikes(ServerWorld world, PlayerEntity player) {
        Vec3d start = player.getEyePos();
        Vec3d direction = player.getRotationVec(1.0f).normalize();
        Vec3d end = start.add(direction.multiply(12.0));
        BlockHitResult hit = world.raycast(new RaycastContext(start, end, RaycastContext.ShapeType.COLLIDER,
            RaycastContext.FluidHandling.NONE, player));

        BlockPos aim = hit.getType() == HitResult.Type.MISS
            ? BlockPos.ofFloored(player.getX() + direction.x * 6.0, player.getY(), player.getZ() + direction.z * 6.0)
            : hit.getBlockPos().offset(hit.getSide());

        int[][] offsets = {
            {0, 0}, {2, 0}, {-2, 0}, {0, 2}, {0, -2},
            {1, 1}, {-1, 1}, {1, -1}, {-1, -1},
            {3, 1}, {-3, 1}, {3, -1}, {-3, -1}
        };

        for (int i = 0; i < offsets.length; i++) {
            BlockPos column = aim.add(offsets[i][0], 0, offsets[i][1]);
            BlockPos base = world.getTopPosition(Heightmap.Type.MOTION_BLOCKING, column);
            if (!world.getBlockState(base).isAir() || !world.getBlockState(base.down()).isSolidBlock(world, base.down())) continue;

            int height = (i == 0 || i % 4 == 1) ? 2 : 1;
            for (int y = 0; y < height; y++) {
                BlockPos spikePos = base.up(y);
                if (!world.getBlockState(spikePos).isAir() || world.getBlockEntity(spikePos) != null) break;
                world.setBlockState(spikePos, SpartanBoss.GLACIAL_SPIKE.getDefaultState(), 3);
                world.spawnParticles(ParticleTypes.SNOWFLAKE, spikePos.getX() + 0.5, spikePos.getY() + 0.55,
                    spikePos.getZ() + 0.5, 12, 0.22, 0.32, 0.22, 0.025);
                world.spawnParticles(new DustParticleEffect(0x79DFFF, 1.0f), spikePos.getX() + 0.5,
                    spikePos.getY() + 0.6, spikePos.getZ() + 0.5, 7, 0.18, 0.25, 0.18, 0.02);
            }
        }

        Vec3d center = Vec3d.ofCenter(aim);
        world.spawnParticles(new DustParticleEffect(0x74DFFF, 2.0f), center.x, center.y + 0.4, center.z,
            100, 3.0, 0.35, 3.0, 0.04);
        world.spawnParticles(ParticleTypes.SNOWFLAKE, center.x, center.y + 0.5, center.z,
            140, 3.0, 1.0, 3.0, 0.06);
        player.playSound(SpartanBoss.FROST_SOUND, 2.0f, 0.62f);
    }

    private static boolean startChainSlash(ServerWorld world, PlayerEntity player) {
        if (ACTIVE_SLASHES.containsKey(player.getUuid())) return false;
        ACTIVE_SLASHES.put(player.getUuid(), new SlashState());
        player.playSound(SpartanBoss.CHAIN_SOUND, 1.8f, 0.82f);
        world.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 1.0, player.getZ(),
            25, 0.45, 0.55, 0.45, 0.04);
        return true;
    }

    private static void tickChainSlash(ServerWorld world, ServerPlayerEntity player, SlashState state) {
        if (state.ticks % CHAIN_SLASH_INTERVAL == 0 && state.strikeIndex < 3) {
            performChainStrike(world, player, state.strikeIndex);
            state.strikeIndex++;
        }
        state.ticks++;
        if (state.strikeIndex >= 3 && state.ticks > (2 * CHAIN_SLASH_INTERVAL + 2)) {
            ACTIVE_SLASHES.remove(player.getUuid());
        }
    }

    private static void performChainStrike(ServerWorld world, PlayerEntity player, int strike) {
        Vec3d facing = player.getRotationVec(1.0f).normalize();
        Vec3d side = new Vec3d(-facing.z, 0, facing.x).normalize();
        double length = strike == 2 ? 5.5 : 4.8;
        for (int point = 1; point <= 12; point++) {
            double progress = point / 12.0;
            Vec3d trail = player.getEyePos().add(facing.multiply(length * progress))
                .add(side.multiply((strike == 1 ? -1 : 1) * Math.sin(progress * Math.PI) * 1.4));
            world.spawnParticles(strike == 2 ? ParticleTypes.FLAME : ParticleTypes.CRIT,
                trail.x, trail.y, trail.z, 3, 0.08, 0.08, 0.08, 0.02);
            world.spawnParticles(new DustParticleEffect(0xFF5A16, 1.3f),
                trail.x, trail.y, trail.z, 2, 0.05, 0.05, 0.05, 0.01);
        }
        world.spawnParticles(ParticleTypes.SWEEP_ATTACK, player.getX() + facing.x * 2.0,
            player.getY() + 1.0, player.getZ() + facing.z * 2.0, 1, 0, 0, 0, 0);
        player.playSound(SpartanBoss.CHAIN_SOUND, 1.25f, strike == 2 ? 0.68f : (strike == 0 ? 0.9f : 1.05f));

        float damage = strike == 2 ? 9.0f : 7.0f;
        Box hitArea = player.getBoundingBox().expand(5.5, 3.0, 5.5);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, hitArea,
                entity -> entity != player && entity.isAlive() && !player.isTeammate(entity)
                    && (!(entity instanceof PlayerEntity p) || (!p.isCreative() && !p.isSpectator())))) {
            Vec3d offset = target.getEyePos().subtract(player.getEyePos());
            double distance = offset.length();
            if (distance > length + 0.9 || distance < 0.1 || offset.normalize().dotProduct(facing) < 0.18) continue;
            target.damage(world, player.getDamageSources().playerAttack(player), damage);
            target.setOnFireFor(2);
            if (strike == 2) {
                Vec3d knockback = target.getEntityPos().subtract(player.getEntityPos()).normalize();
                target.setVelocity(knockback.multiply(0.65).add(0, 0.2, 0));
                target.velocityDirty = true;
            }
        }
    }

    private static boolean spartanFury(ServerWorld world, PlayerEntity player) {
        if (ACTIVE_FURY.containsKey(player.getUuid())) return false;
        ACTIVE_FURY.put(player.getUuid(), SPARTAN_FURY_TICKS);
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, SPARTAN_FURY_TICKS, 1, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, SPARTAN_FURY_TICKS, 1, false, false));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, SPARTAN_FURY_TICKS, 0, false, false));
        world.spawnParticles(new DustParticleEffect(0xE31B23, 2.1f), player.getX(), player.getY() + 1.0, player.getZ(),
            95, 1.0, 0.8, 1.0, 0.07);
        world.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 0.8, player.getZ(),
            65, 0.8, 0.7, 0.8, 0.05);
        world.spawnParticles(ParticleTypes.CRIT, player.getX(), player.getY() + 1.0, player.getZ(),
            40, 0.7, 0.8, 0.7, 0.1);
        player.playSound(SpartanBoss.RAGE_SOUND, 2.0f, 0.85f);
        return true;
    }

    private static void divineDash(ServerWorld world, PlayerEntity player) {
        Vec3d direction = player.getRotationVec(1.0f).normalize();
        Vec3d start = player.getEntityPos();
        Vec3d lastSafe = start;
        double maxDistance = 15.0;

        for (double distance = 0.5; distance <= maxDistance; distance += 0.5) {
            Vec3d candidate = start.add(direction.multiply(distance));
            Box candidateBox = player.getBoundingBox().offset(candidate.subtract(start));
            if (!world.isSpaceEmpty(player, candidateBox)) break;
            lastSafe = candidate;
        }

        Vec3d travel = lastSafe.subtract(start);
        if (travel.lengthSquared() > 0.01) {
            player.requestTeleport(lastSafe.x, lastSafe.y, lastSafe.z);
            int points = Math.max(2, (int) Math.ceil(travel.length() * 3.0));
            for (int i = 0; i <= points; i++) {
                Vec3d point = start.add(travel.multiply(i / (double) points)).add(0, 0.8, 0);
                world.spawnParticles(ParticleTypes.END_ROD, point.x, point.y, point.z,
                    5, 0.12, 0.15, 0.12, 0.04);
                world.spawnParticles(new DustParticleEffect(0xFFF0B0, 1.35f),
                    point.x, point.y, point.z, 3, 0.08, 0.1, 0.08, 0.02);
            }
        }
        player.playSound(SpartanBoss.DIVINE_SOUND, 1.8f, 1.5f);
    }

    private static boolean divineDescent(ServerWorld world, ServerPlayerEntity player) {
        if (ACTIVE_DESCENTS.containsKey(player.getUuid()) || player.isCreative() || player.isSpectator()) return false;
        PlayerAbilities abilities = player.getAbilities();
        FlightState state = new FlightState(abilities.allowFlying, abilities.flying);
        ACTIVE_DESCENTS.put(player.getUuid(), state);

        abilities.allowFlying = true;
        abilities.flying = true;
        player.sendAbilitiesUpdate();
        player.setVelocity(player.getVelocity().x, 0.85, player.getVelocity().z);
        player.velocityDirty = true;
        world.spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(),
            70, 0.6, 0.8, 0.6, 0.08);
        world.spawnParticles(new DustParticleEffect(0xFFF2B0, 2.0f), player.getX(), player.getY() + 1.0, player.getZ(),
            50, 0.5, 0.7, 0.5, 0.05);
        player.playSound(SpartanBoss.DIVINE_SOUND, 2.0f, 1.0f);
        return true;
    }

    public static void tickServer(MinecraftServer server) {
        Set<UUID> online = new HashSet<>();
        for (ServerPlayerEntity player : server.getPlayerManager().getPlayerList()) {
            online.add(player.getUuid());

            SlashState slash = ACTIVE_SLASHES.get(player.getUuid());
            if (slash != null && player.getEntityWorld() instanceof ServerWorld world) {
                tickChainSlash(world, player, slash);
            }

            Integer furyTicks = ACTIVE_FURY.get(player.getUuid());
            if (furyTicks != null && furyTicks > 0 && furyTicks % 3 == 0 && player.getEntityWorld() instanceof ServerWorld world) {
                world.spawnParticles(new DustParticleEffect(0xE31B23, 1.35f), player.getX(), player.getY() + 1.0,
                    player.getZ(), 8, 0.45, 0.65, 0.45, 0.025);
                world.spawnParticles(ParticleTypes.FLAME, player.getX(), player.getY() + 0.8, player.getZ(),
                    3, 0.3, 0.4, 0.3, 0.015);
            }

            FlightState flight = ACTIVE_DESCENTS.get(player.getUuid());
            if (flight != null && player.getEntityWorld() instanceof ServerWorld world) {
                if (!player.isAlive()) {
                    cancelPlayer(player);
                } else {
                    tickDivineDescent(world, player, flight);
                }
            }
        }

        ACTIVE_SLASHES.keySet().removeIf(id -> !online.contains(id));
        ACTIVE_DESCENTS.keySet().removeIf(id -> !online.contains(id));
        ACTIVE_FURY.keySet().removeIf(id -> !online.contains(id));
        ACTIVE_FURY.replaceAll((id, ticks) -> ticks - 1);
        ACTIVE_FURY.values().removeIf(ticks -> ticks <= 0);

        long now = server.getOverworld().getTime();
        PLAYER_COOLDOWNS.entrySet().removeIf(entry -> !online.contains(entry.getKey())
            && allCooldownsExpired(entry.getValue(), now));

        Iterator<Map.Entry<UUID, StunState>> iterator = ACTIVE_STUNS.entrySet().iterator();
        while (iterator.hasNext()) {
            StunState state = iterator.next().getValue();
            LivingEntity entity = state.entity;
            if (!entity.isAlive() || entity.isRemoved()) {
                restoreStun(state);
                iterator.remove();
                continue;
            }

            state.ticksRemaining--;
            if (state.ticksRemaining <= 0) {
                restoreStun(state);
                iterator.remove();
                continue;
            }

            entity.setVelocity(Vec3d.ZERO);
            entity.velocityDirty = true;
            if (state.ticksRemaining % 5 == 0 && entity.getEntityWorld() instanceof ServerWorld stunWorld) {
                stunWorld.spawnParticles(ParticleTypes.SNOWFLAKE, entity.getX(), entity.getY() + 0.9, entity.getZ(),
                    5, 0.28, 0.48, 0.28, 0.015);
                stunWorld.spawnParticles(new DustParticleEffect(0x8BE5FF, 0.9f),
                    entity.getX(), entity.getY() + 0.8, entity.getZ(), 3, 0.18, 0.32, 0.18, 0.01);
            }
            if (entity instanceof PlayerEntity player) {
                player.stopUsingItem();
                Vec3d locked = state.origin;
                if (player.getEntityPos().squaredDistanceTo(locked) > 0.0025) {
                    player.requestTeleport(locked.x, locked.y, locked.z);
                }
            }
        }
    }

    private static void tickDivineDescent(ServerWorld world, ServerPlayerEntity player, FlightState state) {
        state.ticks++;
        if (!state.diving && state.ticks >= DIVINE_DESCENT_FLIGHT_TICKS) {
            PlayerAbilities abilities = player.getAbilities();
            abilities.flying = false;
            abilities.allowFlying = state.previousAllowFlying;
            player.sendAbilitiesUpdate();
            Vec3d velocity = player.getVelocity();
            player.setVelocity(velocity.x * 0.25, -1.55, velocity.z * 0.25);
            player.velocityDirty = true;
            state.diving = true;
            state.diveTicks = 0;
            world.spawnParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(),
                45, 0.45, 0.55, 0.45, 0.05);
            player.playSound(SpartanBoss.CRASH_SOUND, 1.6f, 1.2f);
            return;
        }

        if (state.diving) {
            // Keep the crash compulsory even on servers where another mod or permission
            // grants flight; the original flight permission is restored after impact.
            PlayerAbilities abilities = player.getAbilities();
            if (abilities.flying) {
                abilities.flying = false;
                player.sendAbilitiesUpdate();
            }
            state.diveTicks++;
            if (player.isOnGround() && state.diveTicks > 2) {
                finishDivineImpact(world, player, state);
            } else if (state.diveTicks > 80) {
                finishDivineImpact(world, player, state);
            }
        }
    }

    private static void finishDivineImpact(ServerWorld world, ServerPlayerEntity player, FlightState state) {
        if (!ACTIVE_DESCENTS.containsKey(player.getUuid())) return;
        ACTIVE_DESCENTS.remove(player.getUuid());
        PlayerAbilities abilities = player.getAbilities();
        abilities.flying = state.previousFlying && state.previousAllowFlying;
        abilities.allowFlying = state.previousAllowFlying;
        player.sendAbilitiesUpdate();

        Vec3d center = player.getEntityPos();
        world.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, center.x, center.y + 0.2, center.z, 1, 0, 0, 0, 0);
        world.spawnParticles(ParticleTypes.FLASH, center.x, center.y + 0.5, center.z, 1, 0, 0, 0, 0);
        world.spawnParticles(ParticleTypes.END_ROD, center.x, center.y + 0.5, center.z,
            130, 2.8, 1.0, 2.8, 0.14);
        world.spawnParticles(new DustParticleEffect(0xFFF0A0, 2.1f), center.x, center.y + 0.3, center.z,
            100, 2.4, 0.7, 2.4, 0.1);

        Box area = player.getBoundingBox().expand(7.0);
        for (LivingEntity target : world.getEntitiesByClass(LivingEntity.class, area,
                entity -> entity != player && entity.isAlive() && !player.isTeammate(entity)
                    && (!(entity instanceof PlayerEntity p) || (!p.isCreative() && !p.isSpectator())))) {
            if (target.squaredDistanceTo(player) > 49.0) continue;
            BossBalance.applyTieredDamage(world, target, player.getDamageSources().playerAttack(player),
                GabrielEntity.CRASH_BASE_DAMAGE, BossBalance.AttackTier.ULTIMATE);
            Vec3d knockback = target.getEntityPos().subtract(center).normalize();
            target.setVelocity(knockback.multiply(1.4).add(0, 0.45, 0));
            target.velocityDirty = true;
        }
        player.playSound(SpartanBoss.CRASH_SOUND, 2.5f, 0.8f);
    }

    private static boolean allCooldownsExpired(long[] cooldowns, long now) {
        for (long readyAt : cooldowns) if (readyAt > now) return false;
        return true;
    }

    public static boolean isStunned(Entity entity) {
        return ACTIVE_STUNS.containsKey(entity.getUuid());
    }

    public static void cancelPlayer(ServerPlayerEntity player) {
        SlashState slash = ACTIVE_SLASHES.remove(player.getUuid());
        FlightState flight = ACTIVE_DESCENTS.remove(player.getUuid());
        if (flight != null) {
            PlayerAbilities abilities = player.getAbilities();
            abilities.flying = flight.previousFlying && flight.previousAllowFlying;
            abilities.allowFlying = flight.previousAllowFlying;
            player.sendAbilitiesUpdate();
        }
    }

    private static final class SlashState {
        private int ticks;
        private int strikeIndex;
    }

    private static final class FlightState {
        private final boolean previousAllowFlying;
        private final boolean previousFlying;
        private int ticks;
        private boolean diving;
        private int diveTicks;

        private FlightState(boolean previousAllowFlying, boolean previousFlying) {
            this.previousAllowFlying = previousAllowFlying;
            this.previousFlying = previousFlying;
        }
    }

    private static final class StunState {
        private final LivingEntity entity;
        private final ServerWorld originWorld;
        private final Vec3d origin;
        private final boolean previousAiDisabled;
        private final StatusEffectInstance previousSlowness;
        private final StatusEffectInstance previousWeakness;
        private final StatusEffectInstance previousMiningFatigue;
        private int ticksRemaining;

        private StunState(LivingEntity entity, ServerWorld world, int ticks) {
            this.entity = entity;
            this.originWorld = world;
            this.origin = entity.getEntityPos();
            this.ticksRemaining = ticks;
            this.previousAiDisabled = entity instanceof MobEntity mob && mob.isAiDisabled();
            this.previousSlowness = entity instanceof PlayerEntity player ? copyEffect(player.getStatusEffect(StatusEffects.SLOWNESS)) : null;
            this.previousWeakness = entity instanceof PlayerEntity player ? copyEffect(player.getStatusEffect(StatusEffects.WEAKNESS)) : null;
            this.previousMiningFatigue = entity instanceof PlayerEntity player ? copyEffect(player.getStatusEffect(StatusEffects.MINING_FATIGUE)) : null;
        }
    }
}
